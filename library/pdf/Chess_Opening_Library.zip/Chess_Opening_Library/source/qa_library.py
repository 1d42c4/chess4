import sys,json,collections,io,hashlib,os,subprocess,concurrent.futures
from pathlib import Path
ROOT=Path(__file__).parent;sys.path.insert(0,str(ROOT/'lib'))
import chess,chess.pgn
from pypdf import PdfReader
from PIL import Image,ImageOps,ImageDraw
OUT=ROOT.parent/'rebuilt'
manifest=json.loads((OUT/'manifest.json').read_text())
layouts=json.loads((ROOT/'layout_boxes.json').read_text());boards=json.loads((ROOT/'diagram_manifest.json').read_text())
errors=[];collisions=[];by_page=collections.defaultdict(list)
for r in layouts:by_page[(r['pdf'],r['page'])].append(r)
for r in boards:
    b=chess.Board(r['fen'])
    if not b.is_valid():errors.append(('invalid_fen',r))
    by_page[(r['pdf'],r['page'])].append(dict(x=r['x'],y=r['y'],w=r['size'],h=r['size'],text='[BOARD]'))
def intersect(a,b):
    return min(a['x']+a['w'],b['x']+b['w'])-max(a['x'],b['x'])>1 and min(a['y']+a['h'],b['y']+b['h'])-max(a['y'],b['y'])>1
for page,rs in by_page.items():
    for i,a in enumerate(rs):
        for b in rs[i+1:]:
            if intersect(a,b):collisions.append(dict(pdf=page[0],page=page[1],a=a['text'][:150],b=b['text'][:150]))
for m in manifest:
    path=OUT/m['path'];r=PdfReader(path)
    if len(r.pages)!=m['pages']:errors.append(('page_count',m['path']))
    for i,p in enumerate(r.pages):
        text=p.extract_text()
        if not text or '\ufffd' in text or '\u25a0' in text:errors.append(('bad_text',m['path'],i+1))
        if float(p.mediabox.width)!=612 or float(p.mediabox.height)!=792:errors.append(('page_size',m['path']))
    m['sha256']=hashlib.sha256(path.read_bytes()).hexdigest();m['bytes']=path.stat().st_size
pgngames=0;pgnnodes=0
for path in OUT.glob('*/*.pgn'):
    n=0
    with path.open(encoding='utf-8') as f:
        while g:=chess.pgn.read_game(f):
            n+=1;pgngames+=1
            if g.errors:errors.append(('pgn_parse',str(path),str(g.errors)))
            stack=[g]
            while stack:
                node=stack.pop();b=node.board()
                if not b.is_valid():errors.append(('pgn_board',str(path)))
                for v in node.variations:
                    pgnnodes+=1
                    if v.move not in b.legal_moves:errors.append(('pgn_move',str(path)))
                    stack.append(v)
    if n==0:errors.append(('empty_pgn',str(path)))
qa=dict(pdfs=len(manifest),pages=sum(m['pages'] for m in manifest),diagrams=len(boards),pgn_games=pgngames,pgn_nodes=pgnnodes,
    errors=errors,collisions=collisions)
(ROOT/'qa_results.json').write_text(json.dumps(qa,indent=2));(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({**qa,'collisions':len(collisions)}),flush=True)
if '--render' in sys.argv:
    renderdir=ROOT/'qa_all';renderdir.mkdir(exist_ok=True)
    exe='pdftoppm'
    def render(m):
        stem=m['path'].replace('/','_').replace('\\','_').removesuffix('.pdf');pref=renderdir/stem
        proc=subprocess.run([exe,'-r','65','-png',str(OUT/m['path']),str(pref)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=0x08000000)
        files=list(renderdir.glob(stem+'-*.png'))
        if proc.returncode or len(files)!=m['pages']:return (m['path'],proc.returncode,len(files),proc.stderr.decode(errors='replace')[:300])
        for f in files:
            im=Image.open(f);im.load()
            if im.width<500 or im.height<700:return ('bad_render',str(f))
        return None
    results=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        for n,r in enumerate(pool.map(render,manifest),1):
            if r:results.append(r)
            if n%20==0:print('RENDERED',n,'PDFs',flush=True)
    (ROOT/'render_results.json').write_text(json.dumps(dict(errors=results,pdfs=len(manifest)),indent=2))
    # One contact sheet per course: every page visible for a complete layout pass.
    for i in range(1,51):
        fs=sorted(renderdir.glob(f'{i:02d}_*.png'))
        sheet=Image.new('RGB',(1600,((len(fs)+5)//6)*365),'#b6bec5')
        d=ImageDraw.Draw(sheet)
        for j,f in enumerate(fs):
            im=ImageOps.contain(Image.open(f),(255,330));x=(j%6)*266+5;y=(j//6)*365+23;sheet.paste(im,(x,y));d.text((x,y-18),f.stem.split('_')[-1],fill='#111111')
        sheet.save(renderdir/f'contact_{i:02d}.jpg',quality=88)
    fs=sorted(renderdir.glob('00_Start_Here-*.png'))
    sheet=Image.new('RGB',(1600,((len(fs)+5)//6)*365),'#b6bec5');d=ImageDraw.Draw(sheet)
    for j,f in enumerate(fs):
        im=ImageOps.contain(Image.open(f),(255,330));x=(j%6)*266+5;y=(j//6)*365+23;sheet.paste(im,(x,y));d.text((x,y-18),f.stem,fill='#111111')
    sheet.save(renderdir/'contact_00.jpg',quality=88)
    print('RENDER FINISHED',len(results),'errors',flush=True)
