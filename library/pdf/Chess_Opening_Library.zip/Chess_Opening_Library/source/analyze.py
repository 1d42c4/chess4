import sys,json,time,os
from pathlib import Path
ROOT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'lib'))
import chess,chess.engine
from all_courses import COURSES
ENGINE=Path(os.environ.get('STOCKFISH_EXECUTABLE',str(ROOT/'assets/stockfish/stockfish/stockfish-windows-x86-64-sse41-popcnt.exe')))
CACHE=ROOT/'engine_cache.json'
cache=json.loads(CACHE.read_text()) if CACHE.exists() else {}
engine=chess.engine.SimpleEngine.popen_uci(str(ENGINE),creationflags=0x08000000)
engine.configure({'Threads':2,'Hash':128})
def packed(info):
    return dict(cp=info['score'].white().score(mate_score=100000),mate=info['score'].white().mate(),
        depth=info.get('depth'),nodes=info.get('nodes'),pv=[m.uci() for m in info.get('pv',[])])
def get(b,kind):
    key=b.fen()+'|'+kind
    if key not in cache:
        n=60000 if kind=='scan' else 350000
        infos=engine.analyse(b,chess.engine.Limit(nodes=n),multipv=1 if kind=='scan' else 3)
        cache[key]=[packed(i) for i in infos]
    return cache[key]
def save():
    temp=CACHE.with_suffix('.tmp');temp.write_text(json.dumps(cache));temp.replace(CACHE)
def complete_pvs(b):
    for info in get(b,'practice'):
        continuation=b.copy()
        for uci in info['pv']:continuation.push_uci(uci)
        while len(info['pv'])<8 and not continuation.is_game_over():
            extra=engine.analyse(continuation,chess.engine.Limit(nodes=350000))
            moves=extra.get('pv',[])[:8-len(info['pv'])]
            if not moves:raise RuntimeError('Missing continuation in a nonterminal position')
            info.setdefault('extension_searches',[]).append(dict(fen=continuation.fen(),nodes=extra.get('nodes'),depth=extra.get('depth')))
            for m in moves:
                assert m in continuation.legal_moves
                info['pv'].append(m.uci());continuation.push(m)
audit=[]
try:
    for c in COURSES:
        for line in c['branches']:
            b=chess.Board()
            for ply,san in enumerate(line['moves'].split()):
                before=get(b,'scan')[0]['cp'];turn=b.turn;m=b.parse_san(san);prev=b.copy();b.push(m)
                after=get(b,'scan')[0]['cp'];loss=(before-after)*(1 if turn else -1)
                if loss>140:
                    strong=engine.analyse(prev,chess.engine.Limit(nodes=650000),multipv=1)[0]
                    forced=engine.analyse(prev,chess.engine.Limit(nodes=450000),root_moves=[m],multipv=1)[0]
                    delta=strong['score'].pov(turn).score(mate_score=100000)-forced['score'].pov(turn).score(mate_score=100000)
                    if delta>120:
                        item=dict(course=c['name'],branch=line['label'],ply=ply+1,san=san,loss=delta,
                            alternative=prev.san(strong['pv'][0]),fen=prev.fen())
                        audit.append(item);print('REVIEW',json.dumps(item),flush=True)
            complete_pvs(b)
        save(); print('DONE',c['name'],'positions',len(cache),flush=True)
    (ROOT/'line_review.json').write_text(json.dumps(audit,indent=2))
    print('FINISHED',len(COURSES),'courses;',len(audit),'review items',flush=True)
finally:
    save();engine.quit()
