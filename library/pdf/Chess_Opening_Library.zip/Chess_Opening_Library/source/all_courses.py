from course_data import COURSES
import data_open
import data_sicilian
import data_defenses
import data_queens
import data_indian
import data_flank
for course in COURSES:
    course['name']=course['name'].replace(' s ', "'s ")
    for line in course['branches']:
        line['label']=line['label'].replace(' s ', "'s ")
assert len(COURSES)==50
