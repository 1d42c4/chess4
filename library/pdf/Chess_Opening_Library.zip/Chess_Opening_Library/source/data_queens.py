from course_data import add

add('Queen s Gambit Declined','Queen-pawn centers','Foundation',
'Black supports d5 with ...e6 rather than taking the c4 pawn immediately. The defense teaches central tension, development of the restricted c8 bishop and the balance between solid structure and active play.',
'Develop the pieces before choosing the central exchange. In the Exchange variation, use the Carlsbad structure to plan a minority attack or central expansion; in other lines, pressure d5 and improve piece activity.',
'Complete development, resolve the c8 bishop and aim for ...c5 or ...e5. Exchange pieces when it reduces the space problem without leaving a passive endgame.',
'The Exchange often gives White pawns on a2/b2 against Black a7/b7/c6. A minority attack seeks a weakness, usually on c6; it is not a race to promote the b-pawn.',
'Do not confuse a solid position with a position that needs no active plan. White should also avoid launching b4-b5 before the pieces and king are ready.',
'Study the Slav and Semi-Slav to see how ...c6 changes the center and the c8 bishop. The Tarrasch illustrates a more active isolated-pawn alternative.',[
('Orthodox development','d4 d5 c4 e6 Nc3 Nf6 Bg5 Be7 e3 O-O Nf3 Nbd7 Rc1 c6 Bd3 dxc4 Bxc4 Nd5', 'Black exchanges the c4 pawn and centralizes a knight to ease development. White preserves central pressure. The timing of exchanges matters more than simply retaining all the pieces.'),
('Exchange, Carlsbad structure','d4 d5 c4 e6 Nc3 Nf6 cxd5 exd5 Bg5 Be7 e3 O-O Bd3 Nbd7 Nge2 Re8 O-O c6', 'White retains the option of f3 and e4 because the knight went to e2. A queenside minority attack is another plan. Choose between them by Black\'s piece placement and central counterplay.'),
('Tartakower setup','d4 d5 c4 e6 Nc3 Nf6 Bg5 Be7 e3 O-O Nf3 h6 Bh4 b6 cxd5 Nxd5 Bxe7 Qxe7', 'Black prepares to solve the c8 bishop with ...Bb7 and recaptures on d5 with a knight. The central structure is more fluid than in the Carlsbad.'),
('Tarrasch Defense','d4 d5 c4 e6 Nc3 c5 cxd5 exd5 Nf3 Nc6 g3 Nf6 Bg2 Be7 O-O O-O', 'Black accepts an isolated d-pawn for free development. White seeks a blockade and favorable exchanges; Black seeks activity and a timely ...d4 break. Structural weakness and dynamic compensation must be assessed together.')])

add('Queen s Gambit Accepted','Queen-pawn centers','Foundation',
'Black takes c4 and usually returns the pawn while developing and challenging the center. The opening is not primarily an attempt to win a pawn. It often leads to open play and isolated-pawn structures.',
'Recover c4 while developing, establish central space and castle. If you choose e4 early, be ready for an immediate central counterattack.',
'Develop with ...Nf6 and ...e6 or challenge e4 with ...e5. Use ...c5 to undermine d4 rather than spend too many moves defending the extra pawn.',
'After ...c5 and exchanges, White may have an isolated d-pawn. Earlier e4 systems can produce a broad center or force it to dissolve.',
'Trying to hold c4 with ...b5 can create tactical weaknesses. White should not recover the pawn with a queen if a developing move offers a better route.',
'The isolated-pawn structures connect to the Panov and Alapin. The Slav may also take c4, but the supporting pawn structure is different.',[
('Classical main structure','d4 d5 c4 dxc4 Nf3 Nf6 e3 e6 Bxc4 c5 O-O a6 Qe2 b5 Bb3 Bb7', 'Black gains queenside space while developing the bishop. White keeps central pressure and considers when to advance or exchange d4. The pawn has been returned for activity.'),
('Early e4','d4 d5 c4 dxc4 e4 e5 Nf3 exd4 Bxc4 Nc6 O-O Be6 Bxe6 fxe6', 'Black attacks the center immediately and accepts a structural imbalance after the bishop exchange. White should exploit active pieces rather than assume doubled pawns are decisive.'),
('Quiet e3 move order','d4 d5 c4 dxc4 e3 Nf6 Bxc4 e6 Nf3 c5 O-O Nc6 Nc3 a6', 'White recovers the pawn with the bishop and develops smoothly. Black pressures d4 and can create an isolated pawn after exchanges.'),
('Early queen check','d4 d5 c4 dxc4 Qa4+ Nc6 Nf3 Nf6 e3 e6 Bxc4 Bd7 Qd1', 'White uses a queen check but must spend time finding a safe queen square. Black can develop with tempo. Compare this with the simpler bishop-recapture routes before choosing it.')])

add('Slav Defense','Queen-pawn centers','Foundation',
'Black supports d5 with ...c6 while keeping the c8 bishop free. The Slav balances a solid center with active bishop development. The timing of ...dxc4 and White\'s a4 is central to many main lines.',
'Maintain central pressure and decide whether to exchange on d5 or build e4. Use a4 when needed to discourage Black from holding c4 with ...b5.',
'Develop the light-square bishop outside the pawn chain when safe. If taking c4, use the time to develop and challenge the center rather than merely defend a pawn.',
'The Exchange creates a symmetrical pawn structure. Main lines with ...dxc4 can leave White a broad center and Black a solid e6/c6 shell.',
'Developing ...Bf5 too early can leave b7 or d5 tactically vulnerable. White should not assume a4 is always useful in positions where Black has not threatened ...b5.',
'The Semi-Slav adds ...e6 before resolving the bishop and requires a different plan. The Exchange Slav is a useful lesson in creating play from symmetry.',[
('Main line with ...Bf5','d4 d5 c4 c6 Nf3 Nf6 Nc3 dxc4 a4 Bf5 e3 e6 Bxc4 Bb4 O-O O-O', 'White prevents ...b5 and recovers the pawn. Black develops actively with a pin. The struggle revolves around e4 and the central squares rather than material.'),
('Exchange Slav','d4 d5 c4 c6 cxd5 cxd5 Nc3 Nf6 Nf3 Nc6 Bf4 Bf5 e3 e6 Bd3 Bxd3 Qxd3', 'The structure is symmetrical but the queen and minor pieces still create imbalances. Improve the least active piece and calculate central breaks instead of copying moves indefinitely.'),
('Slow Slav','d4 d5 c4 c6 Nf3 Nf6 e3 Bf5 Nc3 e6 Nh4 Bg6 Nxg6 hxg6 Bd3', 'White trades a knight for the active bishop and alters Black\'s kingside pawns. Black gains an open h-file and should evaluate that activity alongside the structural change.'),
('Central e4 advance','d4 d5 c4 c6 Nf3 Nf6 Nc3 dxc4 a4 Bf5 Ne5 Nbd7 Nxc4 Qc7 g3 e5', 'White chooses an active knight route and a fianchetto. Black counters in the center. The early knight moves need a concrete payoff because they delay other development.')])

add('Semi-Slav Defense','Queen-pawn centers','Advanced',
'Black builds the d5/c6/e6 triangle before resolving the c8 bishop. The position is solid but can become extremely sharp when Black takes c4 and expands with ...b5. White\'s choice of Bg5 or e3 changes the character of the game.',
'Develop actively and choose whether to allow the Meran structure or enter sharper Bg5 lines. Use central breaks to challenge Black\'s queenside expansion.',
'Resolve the c8 bishop through ...b5 and ...Bb7 or a central break. Use the pawn triangle as a base for counterplay rather than a reason to remain passive.',
'Meran lines often feature a black queenside pawn advance and central ...c5 or ...e5. Moscow lines can exchange the light-square bishops and reduce tactical tension.',
'Do not mix the Botvinnik, Moscow and Meran move orders. Their similar first moves lead to very different tactical requirements. This course gives selected teaching routes, not full Botvinnik theory.',
'The Slav leaves the light-square bishop freer; the QGD uses ...e6 without necessarily committing ...c6. Compare what each pawn move permits and restricts.',[
('Meran structure','d4 d5 c4 c6 Nf3 Nf6 Nc3 e6 e3 Nbd7 Bd3 dxc4 Bxc4 b5 Bd3 Bb7 O-O a6', 'Black gains space and prepares to develop the bishop. White must react in the center before the queenside expansion becomes comfortable.'),
('Anti-Meran with Qc2','d4 d5 c4 c6 Nf3 Nf6 Nc3 e6 e3 Nbd7 Qc2 Bd6 Bd3 O-O O-O dxc4 Bxc4', 'White waits to commit the bishop and supports e4. Black develops normally before resolving the center. This is a useful route for learning the structure without the sharpest gambit lines.'),
('Moscow variation','d4 d5 c4 c6 Nf3 Nf6 Nc3 e6 Bg5 h6 Bxf6 Qxf6 e3 Nd7 Bd3 dxc4 Bxc4 g6', 'White gives up the bishop pair to reduce immediate tactical tension. Black keeps a solid structure and prepares the king bishop. The imbalance is strategic, not just a count of developed pieces.'),
('Cambridge Springs','d4 d5 c4 e6 Nc3 Nf6 Bg5 Nbd7 Nf3 c6 e3 Qa5 Nd2 Bb4 Qc2 O-O', 'Black creates pressure against c3 and g5 with queen and bishop. White must notice the tactical threats and develop accurately. The queen sortie has a concrete purpose rather than being a generic attacking move.')])
