"""Rebuild the Chess Opening Library. SPDX-License-Identifier: GPL-3.0-or-later"""
import sys,os,io,json,re,csv,hashlib,shutil,math,statistics,unicodedata
from pathlib import Path
from xml.sax.saxutils import escape
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'lib'))
import chess,chess.pgn,chess.svg
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor,Color,white
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph
from reportlab.graphics import renderPDF
from svglib.svglib import svg2rlg
from pypdf import PdfReader
from all_courses import COURSES

OUT=Path(os.environ.get('CHESS_OUTPUT',str(ROOT.parent/'rebuilt')))
ASSETS=ROOT/'assets'
CACHE=json.loads((ROOT/'engine_cache.json').read_text())
INK=HexColor('#111827');MUTED=HexColor('#647084');GREEN=HexColor('#789656');CREAM=HexColor('#eff0d3');GOLD=HexColor('#d8a53a')
FONTDIR=Path(os.environ.get('CHESS_FONT_DIR',str(ROOT/'fonts') if (ROOT/'fonts').exists() else 'C:/Windows/Fonts'))
for n,f in [('Text','NotoSans-Regular.ttf'),('Bold','NotoSans-Bold.ttf'),('Italic','NotoSans-Italic.ttf')]:
    pdfmetrics.registerFont(TTFont(n,str(FONTDIR/f)))
pdfmetrics.registerFontFamily('Text',normal='Text',bold='Bold',italic='Italic',boldItalic='Bold')
PIECES={}
for symbol in 'PNBRQKpnbrqk':
    svg=chess.svg.piece(chess.Piece.from_symbol(symbol))
    svg=svg.replace('#000000','#111827').replace('#000','#111827').replace('#ffffff','#f8f7ec').replace('#fff','#f8f7ec')
    PIECES[symbol]=svg2rlg(io.BytesIO(svg.encode()))

ANCHORS=[6,6,7,8,4,4,3,3,7,5,3,5,10,10,10,16,8,8,8,10,3,5,5,5,6,6,6,8,6,6,6,4,6,8,10,6,6,6,6,8,10,6,2,6,6,3,6,3,12,4]
FILTERS=[
['Italian Game'],['Ruy Lopez'],['Scotch Game','Scotch Gambit'],['Four Knights Game'],['Russian Game'],['Philidor Defense'],['Vienna Game','Vienna Gambit'],["King's Gambit"],['Evans Gambit'],['Ponziani Opening'],["Bishop's Opening"],['Danish Gambit','Center Game'],
['Najdorf'],['Sicilian Defense: Dragon'],['Classical Variation','Richter-Rauzer','Sozin Attack'],['Sveshnikov'],['Taimanov'],['Sicilian Defense: Kan'],['Accelerated Dragon'],['Scheveningen'],['Alapin'],['Sicilian Defense: Closed'],['Grand Prix'],['Rossolimo','Moscow Variation'],
['French Defense'],['Caro-Kann Defense'],['Scandinavian Defense'],['Pirc Defense'],['Modern Defense'],['Alekhine Defense'],["Queen's Gambit Declined","Tarrasch Defense"],["Queen's Gambit Accepted"],['Slav Defense'],['Semi-Slav Defense','Cambridge Springs'],["King's Indian Defense"],['Nimzo-Indian Defense'],["Queen's Indian Defense"],['Grunfeld Defense'],['Bogo-Indian Defense'],['Catalan Opening'],['Benoni Defense: Modern','Benoni Defense: Classical','Benoni Defense: Taimanov','Benoni Defense: Fianchetto'],['Benko Gambit'],['Dutch Defense'],['London System','Jobava London'],['Colle System','Colle-Zukertort'],['Trompowsky Attack'],['English Opening'],['Reti Opening'],["King's Indian Attack"],["Bird Opening","Bird's Opening"]]

def board_for(tokens):
    b=chess.Board()
    for san in tokens:
        m=b.parse_san(san)
        if b.san(m)!=san: raise ValueError(f'Noncanonical SAN {san}: {b.san(m)}')
        b.push(m)
        if not b.is_valid(): raise ValueError('Invalid board')
    return b

def notation(tokens,board=None):
    b=(board or chess.Board()).copy();out=[]
    for i,san in enumerate(tokens):
        if b.turn: out.append(f'{b.fullmove_number}.')
        elif i==0: out.append(f'{b.fullmove_number}...')
        m=b.parse_san(san);out.append(b.san(m));b.push(m)
    return ' '.join(out)

def pv_san(b,uci,limit=8):
    b=b.copy();out=[]
    for s in uci[:limit]:
        m=chess.Move.from_uci(s)
        if m not in b.legal_moves: raise ValueError('Illegal engine PV')
        out.append(b.san(m));b.push(m)
    return out,b

def score(info):
    if info.get('mate') is not None:
        return ('White' if info['mate']>0 else 'Black')+f' mates in {abs(info["mate"])}'
    return f'{info["cp"]/100:+.2f}'

def effect(before,san):
    b=before.copy();m=b.parse_san(san);piece=b.piece_at(m.from_square)
    who='White' if b.turn else 'Black';source=chess.square_name(m.from_square);dest=chess.square_name(m.to_square)
    captured=b.piece_at(m.to_square)
    if b.is_castling(m): desc=f'{who} castles {"kingside" if m.to_square>m.from_square else "queenside"}, moving both king and rook.'
    elif b.is_en_passant(m): desc=f'{who} captures en passant and opens the pawn structure.'
    elif captured: desc=f'{who}\'s {chess.piece_name(piece.piece_type)} captures the {chess.piece_name(captured.piece_type)} on {dest}.'
    elif piece.piece_type==chess.PAWN: desc=f'{who} advances the {source[0]}-pawn from {source} to {dest}.'
    else: desc=f'{who} moves the {chess.piece_name(piece.piece_type)} from {source} to {dest}.'
    b.push(m)
    if b.is_check(): desc+=' This gives check.'
    else:
        targets=[chess.square_name(s) for s in b.attacks(m.to_square) if b.piece_at(s) and b.piece_at(s).color!=piece.color and b.piece_at(s).piece_type!=chess.KING]
        if targets: desc+=' It attacks '+', '.join(targets[:3])+'; an attack is not necessarily a threat to win material.'
        elif piece.piece_type in (chess.KNIGHT,chess.BISHOP,chess.PAWN):
            central=[chess.square_name(s) for s in b.attacks(m.to_square) if s in [chess.D4,chess.E4,chess.D5,chess.E5]]
            if central: desc+=' It controls '+', '.join(central)+'.'
    return desc

def facts(b):
    result=[]
    for color,label in [(chess.WHITE,'White'),(chess.BLACK,'Black')]:
        pawns=list(b.pieces(chess.PAWN,color));central=[chess.square_name(s) for s in pawns if chess.square_file(s) in (2,3,4,5) and chess.square_rank(s) in (2,3,4,5)]
        result.append(f'{label} pawns on files c-f, ranks 3-6: '+(', '.join(central) if central else 'none')+'.')
        files=[chess.square_file(s) for s in pawns];doubled=sorted(set(f for f in files if files.count(f)>1))
        if doubled:result.append(f'{label} doubled-pawn files: '+', '.join(chess.FILE_NAMES[f] for f in doubled)+'.')
    openfiles=[chess.FILE_NAMES[f] for f in range(8) if not (b.pawns & chess.BB_FILES[f])]
    if openfiles:result.append('Files without pawns: '+', '.join(openfiles)+'.')
    return result[:5]

def slug(s):return re.sub(r'[^a-z0-9]+','_',s.lower()).strip('_')

def material(b):
    parts=[]
    for color,label in [(chess.WHITE,'White'),(chess.BLACK,'Black')]:
        counts=[]
        for pt,letter in [(chess.QUEEN,'Q'),(chess.ROOK,'R'),(chess.BISHOP,'B'),(chess.KNIGHT,'N'),(chess.PAWN,'P')]:
            counts.append(str(len(b.pieces(pt,color)))+letter)
        parts.append(label+': '+', '.join(counts))
    return 'Material (Q queen, R rook, B bishop, N knight, P pawn). '+'; '.join(parts)+'.'

DB=[];POSNAMES={}
for volume in 'abcde':
    for row in csv.DictReader((ASSETS/f'{volume}.tsv').open(encoding='utf-8'),delimiter='\t'):
        g=chess.pgn.read_game(io.StringIO(row['pgn']))
        if g.errors:raise ValueError(g.errors)
        b=g.end().board();tokens=[];walk=g.board()
        for m in g.mainline_moves():tokens.append(walk.san(m));walk.push(m)
        assert b.is_valid()
        row.update(tokens=tokens,fen=b.fen(),plies=len(tokens));DB.append(row)
        POSNAMES.setdefault(b.epd(),[]).append(row)

def recognize(tokens):
    b=chess.Board();match=None
    for s in tokens:
        b.push_san(s)
        if b.epd() in POSNAMES:match=POSNAMES[b.epd()][0]
    return match or dict(eco='--',name='General opening position')

def references(i,c):
    terms=FILTERS[i]
    if i==4:terms=["Petrov's Defense",'Petrov Defense','Petroff Defense']
    norm=lambda s:unicodedata.normalize('NFKD',s).encode('ascii','ignore').decode()
    candidates=[r for r in DB if any(norm(t) in norm(r['name']) for t in terms)]
    if i==4:candidates=[r for r in candidates if r['name'].startswith(('Petrov','Petroff','Russian'))]
    if i==32:candidates=[r for r in candidates if r['name'].startswith('Slav Defense')]
    if 12<=i<=23:candidates=[r for r in candidates if r['name'].startswith('Sicilian')]
    if i==13:candidates=[r for r in candidates if 'Accelerated' not in r['name']]
    candidates=sorted(candidates,key=lambda r:(r['plies'],r['name']))
    seen=set();out=[]
    for r in candidates:
        if r['fen'] not in seen:
            seen.add(r['fen']);out.append(r)
    return out

MANIFEST=[];BOARDS=[];LAYOUT=[]
class PDF:
    def __init__(self,path,c,part):
        self.path=path;self.course=c;self.part=part;self.page=0
        self.cv=canvas.Canvas(str(path),pagesize=(612,792),pageCompression=1)
        self.cv.setTitle(c['name']+' - '+part);self.cv.setAuthor('Chess Opening Library')
        self.cv.setSubject('Original chess lessons with validated positions and vector boards')
        self.forms=False
    def p(self,text,x,top,w=516,size=10.5,leading=None,bold=False,color=INK,min_y=52):
        style=ParagraphStyle('p',fontName='Bold' if bold else 'Text',fontSize=size,leading=leading or size*1.38,textColor=color,spaceAfter=0)
        p=Paragraph(text,style);pw,ph=p.wrap(w,1000);bottom=top-ph
        if bottom<min_y:raise ValueError(f'Overflow {self.path.name} p{self.page}: {bottom}: {text[:80]}')
        p.drawOn(self.cv,x,bottom)
        LAYOUT.append(dict(pdf=str(self.path.relative_to(OUT)),page=self.page,x=x,y=bottom,w=pw,h=ph,text=re.sub('<[^>]+>','',text)))
        return bottom
    def new(self,title,kicker=None):
        if self.page:self.cv.showPage()
        self.page+=1;c=self.cv
        c.setFillColor(INK);c.setFont('Bold',8);c.drawString(48,762,self.course['name'].upper())
        c.setFillColor(MUTED);c.setFont('Text',8);c.drawRightString(564,762,self.part)
        c.setStrokeColor(GOLD);c.setLineWidth(2);c.line(48,748,110,748)
        self.p(escape(title),48,730,516,22,27,bold=True)
        if kicker:self.p(escape(kicker),48,670,516,9,color=MUTED)
        c.setFont('Text',7);c.setFillColor(MUTED);c.drawString(48,30,'CHESS OPENING LIBRARY  |  Free learning collection  |  2026-09-04');c.drawRightString(564,30,str(self.page))
        return 680
    def board(self,b,x,top,size=280,caption=None):
        if not b.is_valid():raise ValueError('Invalid diagram')
        if not self.forms:
            for s,d in PIECES.items():
                self.cv.beginForm('piece_'+s,0,0,45,45);renderPDF.draw(d,self.cv,0,0);self.cv.endForm()
            self.forms=True
        y=top-size;sq=size/8;c=self.cv
        for rank in range(8):
            for file in range(8):
                c.setFillColor(CREAM if (rank+file)%2 else GREEN);c.rect(x+file*sq,y+rank*sq,sq,sq,stroke=0,fill=1)
                p=b.piece_at(chess.square(file,rank))
                if p:
                    c.saveState();c.translate(x+file*sq,y+rank*sq);c.scale(sq/45,sq/45);c.doForm('piece_'+p.symbol());c.restoreState()
        c.setStrokeColor(INK);c.setLineWidth(.8);c.rect(x,y,size,size,fill=0,stroke=1)
        c.setFont('Text',7);c.setFillColor(MUTED)
        for f in range(8):c.drawCentredString(x+(f+.5)*sq,y-12,chess.FILE_NAMES[f])
        for r in range(8):c.drawRightString(x-7,y+(r+.5)*sq-2,str(r+1))
        side='White to move' if b.turn else 'Black to move'
        self.p(escape((caption+' | ' if caption else '')+side),x,y-21,size,8,10,color=MUTED)
        BOARDS.append(dict(pdf=str(self.path.relative_to(OUT)),page=self.page,fen=b.fen(),x=x,y=y,size=size,side=side))
        return y-35
    def section(self,title,text,x,top,w=516):
        y=self.p(escape(title),x,top,w,11,bold=True)
        return self.p(escape(text),x,y-6,w,10.3)-14
    def finish(self):
        self.cv.save();pages=len(PdfReader(self.path).pages)
        assert pages==self.page
        MANIFEST.append(dict(path=str(self.path.relative_to(OUT)),pages=pages,bytes=self.path.stat().st_size))

def foundations(c,i,folder):
    tokens=c['branches'][0]['moves'].split();anchor=min(ANCHORS[i],len(tokens));a=board_for(tokens[:anchor]);b=board_for(tokens)
    p=PDF(folder/'01_Foundations_and_Plans.pdf',c,'01 / Foundations & plans')
    p.new(c['name'],f'{c["family"]}  |  {c["level"]}  |  Study both sides')
    p.p(escape(notation(tokens[:anchor])),48,645,516,11,bold=True)
    p.board(a,62,598,296,'Course starting position')
    y=p.section('Your course', 'Volume 1: ideas, structures and move orders. Volume 2: annotated teaching routes and middlegame transitions. Volume 3: practice positions and answers.',383,598,181)
    y=p.section('Branches covered',' / '.join(l['label'] for l in c['branches']),383,y,181)
    p.section('The central idea',c['intro'],48,259)
    p.p('Study one branch first. Replay it from both sides, explain the pawn break, then test yourself in Volume 3. The courses form a learning survey, not an exhaustive tournament repertoire.',48,123,516,9.7)
    p.new('Learn the route, not just the name')
    cut=min(max(6,anchor),len(tokens)-3);cut2=min(cut+4,len(tokens))
    p.board(board_for(tokens[:cut]),60,665,214,f'After {notation(tokens[cut-1:cut],board_for(tokens[:cut-1]))}')
    p.board(board_for(tokens[:cut2]),336,665,214,f'After {notation(tokens[cut2-1:cut2],board_for(tokens[:cut2-1]))}')
    y=p.p(escape(notation(tokens)),48,405,516,11,bold=True)-15
    picks=sorted(set([1,min(3,len(tokens)-1),min(5,len(tokens)-1),max(0,anchor-1),min(anchor+2,len(tokens)-1)]))
    for k in picks:
        before=board_for(tokens[:k]);y=p.p('<b>'+escape(notation(tokens[k:k+1],before))+'</b>  '+escape(effect(before,tokens[k])),48,y,516,9.5)-7
    p.p('The notes above describe board facts. To choose a move in a new position, combine those facts with the plans on the next page.',48,min(y-5,112),516,9,color=MUTED)
    p.new('Structure first; plans second')
    p.board(b,62,665,260,'End of the first teaching route')
    y=665
    for fact in facts(b):y=p.p(escape(fact),354,y,210,10)-12
    p.p('These are structural observations, not a verdict. Activity and concrete threats can outweigh pawn weaknesses.',354,y-1,210,9,color=MUTED)
    p.section('White: what to work toward',c['white'],48,351,244)
    p.section('Black: what to work toward',c['black'],320,351,244)
    p.section('How the pawn structure shapes the game',c['structure'],48,191)
    p.p('Before each pawn break: check forcing moves, count attackers and defenders, and visualize the resulting files and squares.',48,94,516,9,color=MUTED)
    p.new('Move orders, tradeoffs & mistakes')
    for j,x in [(0,60),(1,336)]:
        l=c['branches'][j];p.board(board_for(l['moves'].split()),x,665,214,l['label'])
    p.section('What changes between these routes?',c['transfer'],48,402)
    p.section('The mistake to avoid',c['caution'],48,281)
    p.section('A practical decision routine','First identify the opponent\'s threat. Then choose two candidate moves, calculate checks and captures, and compare the resulting structure. If the opponent leaves your memorized line, use this routine instead of guessing the next book move.',48,169)
    p.finish()

def annotated(c,i,folder,refs):
    p=PDF(folder/'02_Annotated_Variations.pdf',c,'02 / Annotated variations')
    p.new('Choose a route through the opening')
    y=674
    for j,l in enumerate(c['branches']):
        r=recognize(l['moves'].split())
        y=p.p(f'<b>{j+1}. {escape(l["label"])}</b>  |  pages {2+j*2}-{3+j*2}',48,y,516,12)-4
        y=p.p(escape(l['note']),48,y,516,10)-18
    p.section('How to read the next pages','Each route starts from the normal initial position. The first page gives its moves and key moments. The second follows a short engine-generated continuation into the middlegame. These continuations are training examples, not historical games or forced predictions.',48,min(y,215))
    p.p('Evaluation numbers use White\'s perspective: positive favors White, negative favors Black. They are search estimates in pawn units, not win probabilities. Near-equal candidates may change order with deeper analysis.',48,109,516,9,color=MUTED)
    for j,l in enumerate(c['branches']):
        tokens=l['moves'].split();b=board_for(tokens);infos=CACHE[b.fen()+'|practice'];r=recognize(tokens)
        p.new(f'{j+1}. {l["label"]}')
        y=p.p(escape(notation(tokens)),48,673,516,11,bold=True)
        top=min(y-20,596)
        p.board(b,62,top,280,'Teaching route endpoint')
        y=p.section('Recognized opening',r['eco']+' - '+r['name'],372,top,192)
        y=p.section('Main lesson',l['note'],372,y,192)
        p.p('The diagram, SAN moves and PGN all come from the same legal move sequence.',372,y,192,8.5,color=MUTED)
        y=top-324
        p.p('Key moments to explain aloud',48,y,516,11,bold=True);y-=25
        start=min(ANCHORS[i],len(tokens)-5)
        ks=sorted(set([max(0,start-1),min(start+2,len(tokens)-1),max(start,len(tokens)-3)]))
        for k in ks:
            before=board_for(tokens[:k]);y=p.p('<b>'+escape(notation(tokens[k:k+1],before))+'</b>  '+escape(effect(before,tokens[k])),48,y,516,9.5)-8
        p.new('From opening to middlegame',l['label'])
        cont,end=pv_san(b,infos[0]['pv'],8)
        p.board(end,62,632,270,'After the illustrative continuation')
        y=p.section('One training continuation',notation(cont,b),367,632,197)
        y=p.section('Position after the line',' '.join(facts(end)[:3]),367,y,197)
        p.p('This line was generated for study; it is not attributed to a played game. Pause before each move and propose your own candidate.',367,y,197,9,color=MUTED)
        y=310;p.p('Other candidates at the original endpoint',48,y,516,11,bold=True);y-=27
        for k,info in enumerate(infos):
            line,_=pv_san(b,info['pv'],6)
            y=p.p(f'<b>{k+1}. {escape(line[0])}  ({escape(score(info))})</b>  '+escape(notation(line,b)),48,y,516,10)-10
        p.p('Exercise: name the pawn break each side should prepare, then identify the piece that must improve before that break is possible. Use Volume 1\'s plans and the actual board, not the opening name alone.',48,min(y-5,136),516,9.5)
    p.new('Further branches: a reference map')
    p.p('The companion Reference_Variations.pgn contains named positions from the Lichess CC0 opening dataset. These are a terminology and move-order reference, not additional engine-approved repertoire recommendations. The eight examples below show where to extend your study.',48,674,516,10)
    # Prefer longer named branches while spreading across early move-order choices.
    selected=[];seen=set()
    for r in sorted(refs,key=lambda r:(abs(r['plies']-14),r['name'])):
        key=tuple(r['tokens'][:min(10,len(r['tokens']))])
        if key in seen:continue
        seen.add(key);selected.append(r)
        if len(selected)==8:break
    if len(selected)<8:
        for r in refs:
            if r not in selected:selected.append(r)
            if len(selected)==8:break
    y=600
    for r in selected:
        if y<190:
            p.new('Further branches: continued');y=674
        y=p.p('<b>'+escape(r['eco']+' - '+r['name'])+'</b>',48,y,516,10)-4
        y=p.p(escape(notation(r['tokens'])),48,y,516,9)-15
    p.p('Source: github.com/lichess-org/chess-openings (retrieved 2026-09-04). The names are reference labels; alternative names and transpositions exist.',48,min(y-8,110),516,8.5,color=MUTED)
    p.finish()

def exercises(c,i,folder):
    p=PDF(folder/'03_Practice_and_Answers.pdf',c,'03 / Practice & answers')
    for j,l in enumerate(c['branches']):
        b=board_for(l['moves'].split());side='White' if b.turn else 'Black'
        p.new(f'Position {j+1}: make a plan',l['label'])
        p.board(b,152,634,308,f'Exercise {j+1}')
        y=273
        for title,text in [('1. Orient yourself','Who moves? Is the king in check? Count material and identify the central pawn structure.'),('2. Choose and calculate',f'Choose two legal moves for {side}. For each, calculate at least four plies (two moves for each side). Include the opponent\'s strongest forcing reply.'),('3. Explain the plan','Name one pawn break and one piece improvement for each side. Explain what would make the break premature.')]:
            y=p.section(title,text,48,y)
        p.cv.setStrokeColor(HexColor('#d7dce2'));p.cv.setLineWidth(.5)
        if y>77:p.cv.line(48,y,564,y)
    for j,l in enumerate(c['branches']):
        tokens=l['moves'].split();b=board_for(tokens);infos=CACHE[b.fen()+'|practice']
        p.new(f'Answer {j+1}: compare your reasoning',l['label'])
        y=p.section('Orientation',('White' if b.turn else 'Black')+' to move. '+('The side to move is in check. ' if b.is_check() else 'The side to move is not in check. ')+material(b)+' '+' '.join(facts(b)[:2]),48,641)
        y=p.section('Strategic explanation',l['note'],48,y)
        for k,info in enumerate(infos):
            line,_=pv_san(b,info['pv'],8)
            y=p.p(f'<b>Candidate {k+1}: {escape(line[0])} | estimate {escape(score(info))}</b>',48,y,516,10)-4
            y=p.p(escape(notation(line,b)),48,y,516,10)-6
            y=p.p(escape(effect(b,line[0])),48,y,516,9)-13
        a=p.section('White: plan to consider',c['white'],48,y,244)
        z=p.section('Black: plan to consider',c['black'],320,y,244)
        p.section('How to score yourself','Award 1 point for correct orientation, 1 for a legal and coherent candidate, 1 for a legal four-ply line, 1 for identifying the opponent\'s counterplay, and 1 for a plan tied to the actual pawn structure. An alternative can be good even if it is absent from this short engine list.',48,min(a,z,179))
    p.new('Review, repeat, then play')
    y=p.section('Your next study session','Replay your preferred branch without looking. Stop at the first forgotten move and explain what it accomplishes. Then play the endpoint from both sides, using a slow time control that gives you time to calculate.',48,671)
    y=p.section('After each game','Record the first unfamiliar position, the move you chose and the plan you missed. Check that position before expanding your opening memory. Save useful discoveries in your own PGN comments.',48,y)
    y=p.section('Spaced review','Review after one day, three days and one week; then adjust the interval to your recall. Repeat positions you cannot explain, even if you remembered the move. A correct explanation is more valuable than reciting a long line.',48,y)
    y=p.section('Connections to other courses',c['transfer'],48,y)
    y=p.section('Sources and checks','Opening names and reference routes: Lichess chess-openings, CC0. Original explanatory text and exercise design: this collection. Legal moves, SAN and FEN: python-chess 1.11.2. Tactical screening and candidate continuations: Stockfish 18. Full search settings and limitations are in QUALITY_REPORT.md.',48,y)
    y=p.p('Source links: <link href="https://github.com/lichess-org/chess-openings" color="#496c34">Lichess opening data</link> | <link href="https://stockfishchess.org/" color="#496c34">Stockfish</link> | <link href="https://python-chess.readthedocs.io/" color="#496c34">python-chess</link>',48,y,516,9)-18
    p.p('Piece artwork: Colin M. L. Burnett, Cburnett set, GPLv2 or later, as supplied by python-chess. Cream/green squares and dark piece outlines follow the provided example.pdf. Editable source and license notices are included for sharing and rebuilding.',48,y,516,9,color=MUTED)
    p.finish()

def export_pgn(c,folder,refs):
    games=[]
    for l in c['branches']:
        g=chess.pgn.Game();g.headers.update(Event=c['name']+' - '+l['label'],Site='Chess Opening Library',Date='2026.09.04',White='Teaching route',Black='Teaching route',Result='*')
        r=recognize(l['moves'].split());g.headers['ECO']=r['eco'];g.comment=c['intro'];node=g;b=g.board()
        for san in l['moves'].split():
            m=b.parse_san(san);node=node.add_variation(m);b.push(m)
        node.comment=l['note']+' END OF AUTHORED OPENING ROUTE. Following variations are illustrative Stockfish 18 continuations, not a historical game.'
        infos=CACHE[b.fen()+'|practice']
        for info in infos:
            cur=node
            for s in info['pv'][:8]:cur=cur.add_variation(chess.Move.from_uci(s))
            cur.comment='Training search estimate from White perspective: '+score(info)
        games.append(str(g))
    (folder/'Annotated_Lines.pgn').write_text('\n\n'.join(games)+'\n',encoding='utf-8')
    refsout=[]
    for r in refs:
        g=chess.pgn.read_game(io.StringIO(r['pgn']));g.headers.update(Event=r['name'],Site='Lichess CC0 opening dataset',ECO=r['eco'],Result='*')
        g.comment='Named-position reference only. Legal move sequence; not an engine-vetted recommendation. Source: https://github.com/lichess-org/chess-openings'
        refsout.append(str(g))
    (folder/'Reference_Variations.pgn').write_text('\n\n'.join(refsout)+'\n',encoding='utf-8')

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    only=int(os.environ.get('CHESS_ONLY','0'))
    for i,c in enumerate(COURSES):
        if only and i+1!=only:continue
        folder=OUT/f'{i+1:02d}_{slug(c["name"])}';folder.mkdir(exist_ok=True)
        refs=references(i,c)
        foundations(c,i,folder);annotated(c,i,folder,refs);exercises(c,i,folder);export_pgn(c,folder,refs)
        print('BUILT',i+1,c['name'],len(refs),'reference routes',flush=True)
    (ROOT/'layout_boxes.json').write_text(json.dumps(LAYOUT))
    (ROOT/'diagram_manifest.json').write_text(json.dumps(BOARDS))
    (OUT/'manifest.json').write_text(json.dumps(MANIFEST,indent=2))
    print('PDFS',len(MANIFEST),'PAGES',sum(x['pages'] for x in MANIFEST),flush=True)
if __name__=='__main__':main()
