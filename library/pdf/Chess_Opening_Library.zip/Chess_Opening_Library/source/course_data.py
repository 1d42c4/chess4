"""Original opening lessons. Lines are teaching routes, not exhaustive repertoires."""
COURSES = []
def add(name, family, level, intro, white, black, structure, caution, transfer, branches):
    COURSES.append(dict(name=name, family=family, level=level, intro=intro, white=white,
        black=black, structure=structure, caution=caution, transfer=transfer,
        branches=[dict(label=x[0], moves=x[1], note=x[2]) for x in branches]))

add('Italian Game','Open games','Foundation',
'White develops the bishop to c4, points at f7 and prepares to castle. The important choice is between an immediate central confrontation and the slower d3 system. A bishop aimed at the king does not by itself justify a sacrifice: count defenders and calculate the reply.',
'Develop Nf3 and castle; use c3 to support d4 when the center can open safely. In quiet positions, Nbd2-f1-g3 can improve the queenside knight after the king and rook are ready.',
'Meet pressure on f7 with normal development. Choose ...Bc5 or ...Nf6, castle, and prepare ...d5 when it can be supported. Preserve a retreat for the c5 bishop if White gains space with b4.',
'With d3 against ...d6, the center is flexible and maneuvering matters. An exchange on d4 can instead create an open e-file or isolated d-pawn. Reassess the position after the central exchange.',
'Ng5 is a concrete branch against the Two Knights, not a universal attacking move. In quiet lines, launching flank pawns before development can allow a central counterstrike.',
'Compare the slow Italian with the Ruy Lopez: both reward preparing d4, but the Italian bishop starts on c4 and can be exposed to ...d5.',[
('Quiet development','e4 e5 Nf3 Nc6 Bc4 Bc5 c3 Nf6 d3 d6 O-O O-O Re1 a6 Bb3 Ba7 Nbd2', 'White keeps the center intact and develops behind it. The knight on d2 can head toward f1; d4 remains an option, not an obligation. Black has time to improve pieces and challenge the center.'),
('Central expansion','e4 e5 Nf3 Nc6 Bc4 Bc5 c3 Nf6 d4 exd4 cxd4 Bb4+ Bd2 Bxd2+ Nbxd2 d5 exd5 Nxd5 O-O', 'The check on b4 makes the move order concrete. Black uses ...d5 to avoid passive defense. White must value activity and development alongside the extra central space.'),
('Two Knights, quiet system','e4 e5 Nf3 Nc6 Bc4 Nf6 d3 Bc5 O-O d6 c3 O-O Re1 a6 Bb3 Ba7 Nbd2', 'The move d3 defends e4 without committing to a tactical fight on f7. The resulting maneuvering position resembles other slow Italians, although the exact piece order still matters.'),
('Two Knights, Ng5','e4 e5 Nf3 Nc6 Bc4 Nf6 Ng5 d5 exd5 Na5 Bb5+ c6 dxc6 bxc6 Be2 h6 Nf3 e4 Ne5 Bd6', 'Black gives a pawn for initiative and gains time against the knight. White should finish development rather than try to keep every pawn. The tempting ...Nxd5 on move five belongs to a different, much sharper branch.')])

add('Ruy Lopez','Open games','Intermediate',
'The bishop on b5 puts pressure on the knight that supports e5. White usually builds a durable center and uses long maneuvers before opening it. Capturing on c6 does not automatically win e5, because Black often has a queen counterattack.',
'Castle early, support e4 with Re1, and prepare c3 and d4. In closed positions, Nbd2-f1-g3 is a common way to strengthen kingside pressure.',
'Use ...a6 and ...b5 to gain space without forgetting development. Challenge White with ...d5 when prepared, or choose an early simplifying system such as the Berlin.',
'Closed lines retain the e4/e5 tension; the Exchange gives Black doubled c-pawns but the bishop pair. The Berlin endgame has a distinct pawn structure and an uncastled king that may be safe after queens come off.',
'Do not assume Bxc6 followed by Nxe5 wins a pawn. Also distinguish ...Nxe4 in the Open Defense from the same capture in a position where tactical support is missing.',
'The Italian shares many maneuvers, but the pressure on c6 changes central tactics. Study the Berlin as a separate endgame lesson, not merely a shortcut through opening theory.',[
('Closed main structure','e4 e5 Nf3 Nc6 Bb5 a6 Ba4 Nf6 O-O Be7 Re1 b5 Bb3 d6 c3 O-O h3', 'White prevents ...Bg4 before committing d4. Black can choose several knight arrangements and central plans. The position rewards understanding the pawn breaks more than memorizing one fixed piece setup.'),
('Berlin endgame','e4 e5 Nf3 Nc6 Bb5 Nf6 O-O Nxe4 d4 Nd6 Bxc6 dxc6 dxe5 Nf5 Qxd8+ Kxd8 Nc3', 'Queens are exchanged and Black loses castling rights, but king exposure is less urgent in an endgame. White has a kingside majority; Black has the bishop pair and must coordinate carefully.'),
('Exchange variation','e4 e5 Nf3 Nc6 Bb5 a6 Bxc6 dxc6 O-O f6 d4 exd4 Nxd4 c5 Nb3 Qxd1 Rxd1', 'White trades a bishop for structural targets. Black answers with active pieces and the bishop pair. A pawn-only ending may favor White, but that does not mean every piece ending does.'),
('Open defense','e4 e5 Nf3 Nc6 Bb5 a6 Ba4 Nf6 O-O Nxe4 d4 b5 Bb3 d5 dxe5 Be6 c3 Be7', 'Black occupies the center actively and must support the advanced e4 knight. White develops with pressure against that center. This is a different strategic battle from the slow Closed Lopez.')])

add('Scotch Game','Open games','Foundation',
'White plays d4 on move three and opens the center before either side has castled. The early exchange gives both sides active development. Because files and diagonals open quickly, queen moves and repeated knight moves need a concrete purpose.',
'Use the central space to develop with tempo. Decide whether to retain a knight on d4, exchange on c6, or accept a structural imbalance. Castle before the open center becomes a liability.',
'Develop against the d4 knight with ...Bc5 or ...Nf6. Attack e4 and use central tactics to make White account for the early opening of the position.',
'After Nxc6 and ...bxc6, Black has doubled c-pawns but extra central control and the b-file. The Scotch Gambit is a different structure: White delays recapturing d4 in exchange for quick development.',
'Do not move the queen repeatedly to defend e4 if development offers a better solution. In gambit lines, distinguish a temporary pawn offer from a promise of a forced attack.',
'The Scotch Gambit can transpose to the Italian. The Four Knights Scotch adds both queenside knights before d4 and is often easier to handle.',[
('Classical Scotch','e4 e5 Nf3 Nc6 d4 exd4 Nxd4 Bc5 Be3 Qf6 c3 Nge7 Bc4 O-O O-O Bb6', 'Black develops with pressure on d4 and f2. White reinforces the center with c3 and can finish development naturally. Do not overlook how a queen on f6 changes kingside tactical threats.'),
('Mieses structure','e4 e5 Nf3 Nc6 d4 exd4 Nxd4 Nf6 Nxc6 bxc6 e5 Qe7 Qe2 Nd5 c4 Ba6 b3 g6', 'White gains space with e5 while the queens pin the central pawns to their kings. This sharp line illustrates why a move that looks like ordinary development can depend on a precise tactical detail.'),
('Scotch Gambit','e4 e5 Nf3 Nc6 d4 exd4 Bc4 Nf6 e5 d5 Bb5 Ne4 Nxd4 Bd7 Bxc6 bxc6 O-O', 'White prioritizes development; Black counters in the center. The pawn count and central structure can change quickly. Assess the resulting position rather than assuming the gambit guarantees an attack.'),
('Four Knights route','e4 e5 Nf3 Nc6 Nc3 Nf6 d4 exd4 Nxd4 Bb4 Nxc6 bxc6 Bd3 d5 exd5 cxd5 O-O O-O', 'Both sides castle into a balanced open position. Black accepts central pawns and activity; White can pressure them. This route is useful for learning open-file play without the sharpest Mieses theory.')])

add('Four Knights Game','Open games','Foundation',
'Both sides develop their knights before deciding the center. The opening is a useful school for rapid development, exchanges and central timing. Symmetry does not guarantee a draw: small differences in bishop placement can make a central break effective.',
'Choose Bb5 for pressure, d4 for an open center, or g3 for a flexible bishop setup. Use development to justify opening the game rather than launching an unsupported attack.',
'Answer White with active development and be ready for ...d5. In symmetrical lines, choose exchanges for a structural reason rather than copying every move automatically.',
'The Scotch route often leaves Black with connected c- and d-pawns after exchanges. The Spanish route can retain a closed center; a fianchetto changes the pressure on d5 and e4.',
'The fork trick after Bc4 and ...Nxe4 is easy to miss: an apparently free knight may allow ...d5 to recover material. Check the center before taking.',
'Use this course as preparation for the Scotch, Ruy Lopez and Vienna. Identify transpositions by the whole position and side to move.',[
('Spanish Four Knights','e4 e5 Nf3 Nc6 Nc3 Nf6 Bb5 Bb4 O-O O-O d3 d6 Bg5 Bxc3 bxc3 Qe7 Re1', 'Black exchanges on c3 to alter the structure; White gains the bishop pair and a central pawn lever. The doubled pawns are a tradeoff, not a verdict on the position.'),
('Scotch Four Knights','e4 e5 Nf3 Nc6 Nc3 Nf6 d4 exd4 Nxd4 Bb4 Nxc6 bxc6 Bd3 d5 exd5 cxd5 O-O O-O', 'Opening the center makes development and king safety immediate priorities. Black aims to use the central pawns actively; White can attack their base after completing development.'),
('Rubinstein counterplay','e4 e5 Nf3 Nc6 Nc3 Nf6 Bb5 Nd4 Nxd4 exd4 e5 dxc3 exf6 Qxf6 dxc3 Bc5 O-O', 'Black offers a temporary knight exchange sequence to disrupt the position. Follow the pawn captures carefully: this branch cannot be handled by mechanically repeating quiet Four Knights moves.'),
('Fianchetto system','e4 e5 Nf3 Nc6 Nc3 Nf6 g3 d5 exd5 Nxd5 Bg2 Nxc3 bxc3 Bd6 O-O O-O d3', 'White develops the bishop on the long diagonal and accepts doubled c-pawns. Black gets central access. The open b-file and bishop activity help explain the structural compromise.')])

add('Petroff Defense','Open games','Foundation',
'Black answers the attack on e5 with an attack on e4. The defense often produces symmetrical pawn structures, but its central captures are tactical. Black normally drives the white knight away before recovering the e4 pawn.',
'Use development and central space to create practical pressure. In main lines, d4 and Bd3 support piece activity; choose exchanges with a clear endgame plan.',
'After Nxe5, play ...d6 before ...Nxe4 in the classical sequence. Develop efficiently and use ...d5 to establish central equality of space.',
'The main line often has opposing d-pawns and open e-files. Symmetry raises the value of active rooks, small weaknesses and correctly timed exchanges.',
'The immediate sequence Nxe5 Nxe4 can expose Black to Qe2 and a discovered attack. Also calculate checks when queens share the e-file.',
'Compare with the Berlin and Four Knights: all can simplify early, but their pawn structures and bishop imbalances are different.',[
('Classical main line','e4 e5 Nf3 Nf6 Nxe5 d6 Nf3 Nxe4 d4 d5 Bd3 Bd6 O-O O-O c4 c6 Nc3 Nxc3 bxc3', 'Black establishes the d5 pawn before finishing development. White uses c4 to test the center. If the c3 knight is exchanged, White gets extra central control but new pawn targets.'),
('Modern attack','e4 e5 Nf3 Nf6 d4 Nxe4 Bd3 d5 Nxe5 Bd6 O-O O-O c4 c6 Nc3 Nxc3 bxc3', 'White plays d4 before exchanging on e5. The resulting position resembles classical Petroff structures, but move-order tactics still need checking.'),
('Nimzowitsch attack','e4 e5 Nf3 Nf6 Nxe5 d6 Nf3 Nxe4 Nc3 Nxc3 dxc3 Be7 Be3 O-O Qd2 Nd7 O-O-O', 'White accepts doubled c-pawns and castles long. Opposite-side castling can make the position much sharper than the Petroff reputation suggests. Black should react to the actual king placement.'),
('Three Knights transposition','e4 e5 Nf3 Nf6 Nc3 Nc6 Bb5 Bb4 O-O O-O d3 d6 Bg5', 'Black can transpose to a Four Knights position. This is a useful reminder that opening names do not replace board recognition; the same position should lead to the same evaluation.')])

add('Philidor Defense','Open games','Foundation',
'Black supports e5 with d6 and accepts a compact position. The price is reduced space and a restricted f8 bishop. Black must seek active development and a timely pawn break rather than simply defend the center forever.',
'Occupy the center with d4 and develop freely. If Black exchanges on d4, use the open files and space without pushing so far that the center becomes weak.',
'Choose a structure deliberately: ...exd4 releases tension, while ...Nd7 and ...Ngf6 retain a compact center. Prepare ...c6 and ...d5 or another justified break.',
'A retained e5 pawn creates a closed, flexible center. An exchange on d4 yields an open e-file and gives White room for piece play.',
'In cramped positions, unnecessary pawn moves can leave Black unable to meet a central opening. White should not assume a space advantage is already a winning attack.',
'The Hanham setup can be reached through 1...d6 and resembles some Pirc positions, but Black has committed the e-pawn to e5.',[
('Exchange structure','e4 e5 Nf3 d6 d4 exd4 Nxd4 Nf6 Nc3 Be7 Be2 O-O O-O Re8 Bf4', 'Black releases the center and develops normally. White has more space and flexible bishops. Both sides should notice opportunities on the e-file as the remaining pieces develop.'),
('Hanham setup','e4 d6 d4 Nf6 Nc3 e5 Nf3 Nbd7 Bc4 Be7 O-O O-O Re1 c6 a4', 'Black keeps the e5 strongpoint and completes development behind it. White restrains queenside expansion with a4. Black still needs a freeing break before the pieces become passive.'),
('Early central simplification','e4 e5 Nf3 d6 d4 Nf6 dxe5 Nxe4 Qd5 Nc5 Bg5 Be7 Bxe7 Qxe7', 'White uses the exposed knight and central queen to ask concrete questions. Black develops while avoiding loss of time. The position is tactical despite the compact opening structure.'),
('Quiet development','e4 d6 d4 Nf6 Nc3 e5 Nf3 Nbd7 Be2 Be7 O-O O-O Re1 c6 Bf1', 'White places the rook on e1 and keeps the bishop flexible. Both sides can improve before committing the center. Evaluate a future d5 or ...d5 by the resulting squares, not just the space gained.')])

add('Vienna Game','Open games','Foundation',
'White develops Nc3 before the kingside knight. This supports e4 and leaves the f-pawn free to advance. The Vienna can become a quiet positional game or a gambit, so the response to ...Nf6 is a key decision.',
'Choose between f4, Bc4 and a quiet g3 setup. If you play f4, account for the weakened king diagonal and prepare development before opening more lines.',
'Challenge the center with ...Nf6 and, in the gambit, ...d5. Against quiet setups, normal development and central control are more useful than grabbing a pawn at any cost.',
'With f4, White offers or advances the f-pawn to influence e5. With g3, White usually maintains e4 and pressures the center with the bishop on g2.',
'After e4 e5 Nc3 Nf6 f4, the central ...d5 is a critical answer. Treat accepting on f4 as a separate branch; do not assume Black must cooperate with White\'s attack.',
'A Vienna with Bc4 can transpose to the Bishop\'s Opening. Nc3 changes some King\'s Gambit positions by controlling d5.',[
('Vienna Gambit, central reply','e4 e5 Nc3 Nf6 f4 d5 fxe5 Nxe4 Nf3 Be7 d4 O-O Bd3 Nxc3 bxc3 c5', 'Black strikes immediately in the center. White gains space but has to develop rapidly. The doubled c-pawns support the center while giving Black targets.'),
('Quiet fianchetto','e4 e5 Nc3 Nf6 g3 d5 exd5 Nxd5 Bg2 Nxc3 bxc3 Bd6 Nf3 O-O O-O', 'White accepts a structural imbalance to develop the bishop actively. Use the open b-file and central control; do not describe doubled pawns as automatically bad.'),
('Bishop development','e4 e5 Nc3 Nc6 Bc4 Nf6 d3 Bc5 Nf3 d6 O-O O-O', 'The game reaches a quiet open-game structure. White has developed the queenside knight before c3, so the standard Italian plan of c3 and d4 is less immediate.'),
('Falkbeer variation','e4 e5 Nc3 Nf6 Bc4 Nxe4 Qh5 Nd6 Bb3 Nc6 Nb5 g6 Qf3 f5', 'This is a tactical branch built around pressure on f7 and the exposed queen. Black gains time and center space. Use calculation rather than general attacking slogans.')])

add('King s Gambit','Open games','Advanced',
'White offers the f-pawn to divert the e5 pawn and accelerate development. The opening teaches initiative and king safety, but Black has several strong defensive choices. A lead in development is compensation to prove, not a guarantee of success.',
'Develop rapidly, control the center and consider recovering f4 only when it does not cost too much time. Calculate checks against the exposed king before starting an attack.',
'Choose between accepting and defending the pawn, returning it for development, or declining with active central play. Do not weaken the king merely to preserve one extra pawn.',
'The f-file may open for White, while the e1-h4 diagonal becomes sensitive. Central pawn exchanges can expose both kings before castling.',
'White has weakened e1-h4 by playing f4. Queen checks on h4 and attacks on the g1 knight must be considered in every forcing line.',
'Compare with the Vienna Gambit and Danish: all trade material or structural security for activity, but the King\'s Gambit specifically changes White\'s king shelter.',[
('Accepted, classical defense','e4 e5 f4 exf4 Nf3 g5 h4 g4 Ne5 Nf6 Bc4 d5 exd5 Bd6 d4 Nh5', 'Black supports the extra pawn and gains space, but creates targets. White attacks the pawn chain and develops actively. Both sides must calculate tactics around the exposed kings.'),
('Fischer defense','e4 e5 f4 exf4 Nf3 d6 d4 g5 h4 g4 Ng1 Bh6 Nc3 c6', 'Black prevents an easy knight jump to e5 before expanding. White may retreat the knight and retain central space. This is a demanding position, not an automatic attacking win.'),
('Declined with Bc5','e4 e5 f4 Bc5 Nf3 d6 Nc3 Nf6 Bc4 Nc6 d3 O-O', 'Black declines the pawn and develops actively. The bishop on c5 points toward g1, making king safety central to White\'s plans. White can maintain central flexibility.'),
('Falkbeer countergambit','e4 e5 f4 d5 exd5 e4 d3 Nf6 dxe4 Nxe4 Nf3 Bc5 Qe2 Bf5', 'Black offers central material to seize development. White should not cling to extra pawns while the king remains in the center. The open e-file makes queen placement important.')])

add('Evans Gambit','Open games','Intermediate',
'From the Italian, White offers b4 to displace the c5 bishop and prepare c3 and d4 with tempo. The main lesson is converting time into central activity. If Black returns material and finishes development, the initiative can disappear.',
'Build the center with c3 and d4, develop the queen and bishops purposefully, and castle. Count the cost of each pawn-recovery move against the time it gives Black.',
'Choose a safe bishop retreat, challenge the center and return material when necessary. Castling and piece coordination are more valuable than defending every pawn.',
'White may have missing b- and c-pawns but active central pieces. Open diagonals toward f7 can matter more than a long-term queenside pawn weakness in the immediate phase.',
'A lead in development expires. Repeated queen moves or slow pawn recovery can leave White simply a pawn down. Black should not assume every apparently free central pawn is safe.',
'Study the Italian first. The Evans is an added gambit branch after ...Bc5, not an option against every response to Bc4.',[
('Accepted, bishop to a5','e4 e5 Nf3 Nc6 Bc4 Bc5 b4 Bxb4 c3 Ba5 d4 exd4 O-O d6 cxd4 Bb6 Nc3', 'White obtains two center pawns and quick development. Black has spent time with the bishop and needs to coordinate. Assess active threats before evaluating the material balance.'),
('Accepted, bishop to e7','e4 e5 Nf3 Nc6 Bc4 Bc5 b4 Bxb4 c3 Be7 d4 Na5 Be2 exd4 Qxd4 Nf6 e5 Nc6', 'Black attacks the active bishop and develops the knight with tempo on the queen. White gains space, but the queen can become a target. Track the timing of e5 carefully.'),
('Return the pawn','e4 e5 Nf3 Nc6 Bc4 Bc5 b4 Bxb4 c3 Ba5 d4 d6 Qb3 Qd7 dxe5 Bb6 exd6 cxd6', 'Black accepts structural concessions to reduce the attack. White\'s queen and bishop target f7, while Black must find safe development. The point is activity, not preserving a perfect pawn chain.'),
('Declined Evans','e4 e5 Nf3 Nc6 Bc4 Bc5 b4 Bb6 a4 a6 Nc3 Nf6 d3 d6 O-O O-O', 'White gains queenside space without sacrificing a pawn. The game returns to a slower maneuvering battle. Black should watch b5 and White should remember that the center is still undecided.')])

add('Ponziani Opening','Open games','Foundation',
'White plays c3 early to support d4. This gains a clear central plan but delays development and takes c3 away from the queenside knight. Black can react immediately in the center rather than allow an ideal pawn duo for free.',
'Use c3 to justify d4, then finish development quickly. If the queen comes out to a4, identify its exact tactical purpose and avoid turning it into a target.',
'Challenge the center with ...d5 or ...Nf6. Exploit White\'s slower development by opening the game when the tactics permit.',
'White may establish e4 and d4, or advance d5 against a knight. An early ...d5 can trade central pawns and expose the queen to tempo attacks.',
'c3 is a supporting move, not a developing move. White cannot afford several more slow moves when Black has already opened the center.',
'Compare with the Italian c3 system: the Ponziani plays c3 before developing the bishop, so Black has more immediate central options.',[
('Central counterstrike','e4 e5 Nf3 Nc6 c3 d5 Qa4 f6 Bb5 Ne7 exd5 Qxd5 d4 Bd7', 'White uses Qa4 to pin the c6 knight. Black reinforces e5 and develops against the queen. The central captures must be calculated because pins affect which recaptures are legal or safe.'),
('Advance against Nf6','e4 e5 Nf3 Nc6 c3 Nf6 d4 Nxe4 d5 Ne7 Nxe5 Nf6 Bc4 d6 Nf3 g6 O-O Bg7', 'White gains time by advancing against the c6 knight and occupies the center. Black reroutes the knights and prepares a fianchetto. Avoid treating the advanced pawns as permanently secure.'),
('Quiet Black setup','e4 e5 Nf3 Nc6 c3 d6 d4 Nf6 Bd3 Be7 O-O O-O Re1', 'Black allows the central duo and develops compactly. White should convert the extra space into coordinated pieces. A later exchange on e4 or d4 will determine the useful files.'),
('Bishop development by Black','e4 e5 Nf3 Nc6 c3 Bc5 d4 exd4 cxd4 Bb4+ Nc3 d5 exd5 Qxd5 Be2', 'The bishop check forces White to resolve development while the center is open. Black\'s queen is active but may lose time to developing moves. Both sides need prompt king safety.')])
