from course_data import add

add('London System','Systems and flank openings','Foundation',
'White develops the c1 bishop to f4 before playing e3. The familiar setup is easy to remember, but it must respond to Black\'s center and queen pressure. A system opening still requires calculation and move-order awareness.',
'Develop Bf4, e3 and the knights, then choose c3 or c4 according to the center. Use Ne5 and a prepared e4 break when appropriate, rather than attacking the king automatically.',
'Challenge d4 with ...c5 and pressure b2 with the queen when justified. Develop the light-square bishop actively if the move order permits.',
'A c3/d4/e3 triangle is solid but restrains White\'s own central expansion. With c4, the game can become a Queen\'s Gambit structure. The Jobava uses Nc3 and has different tactical ideas.',
'Do not play the setup on autopilot against ...Qb6 or an early ...c5. The b2 pawn and uncastled king can become tactical targets.',
'The Colle keeps the c1 bishop inside the pawn chain. The Jobava branch develops Nc3 early and should be treated as an independent choice.',[
('Main ...d5 structure','d4 d5 Nf3 Nf6 Bf4 e6 e3 Bd6 Bxd6 Qxd6 c3 O-O Bd3 c5 Nbd2 Nc6 O-O', 'White exchanges the active bishop and keeps a solid center. Black challenges d4. White should prepare the e4 break rather than assume the usual bishop-based attack is still available.'),
('Against the fianchetto','d4 Nf6 Nf3 g6 Bf4 Bg7 e3 O-O Be2 d6 O-O c5 c3 b6', 'Black develops the king bishop toward the center and prepares queenside coordination. White has a safe setup but must choose a central plan; routine kingside attacks may be ineffective.'),
('Queen pressure on b2','d4 d5 Bf4 c5 e3 Nc6 c3 Qb6 Qb3 c4 Qxb6 axb6 Nd2 b5', 'The queens are exchanged and Black gains queenside space. White must develop against the advancing pawns. This line is an endgame lesson, not a standard London mating pattern.'),
('Jobava London','d4 d5 Nc3 Nf6 Bf4 e6 e3 Bb4 Ne2 O-O a3 Be7', 'White develops Nc3 and asks the bishop to retreat. The knight on e2 keeps f3 and kingside expansion available. Because c3 is occupied by a knight, the usual London pawn triangle is absent.')])

add('Colle System','Systems and flank openings','Foundation',
'White builds d4/e3 and develops the king bishop to d3, usually preparing e4. The system teaches coordinated development and a central break. The Zukertort version develops the queen bishop on b2 instead of keeping it behind the pawn chain.',
'Develop the pieces to support e4 and castle before opening the center. In the Zukertort, use Bb2 and the long diagonal to support central play.',
'Challenge d4 with ...c5, develop actively and prevent an effortless e4 advance. Against a slow setup, consider getting the c8 bishop outside the pawn chain.',
'The e3/d4 center is solid but can restrict the c1 bishop. The e4 break changes the entire position; with b3/Bb2, the bishop is developed but queenside pawns are committed.',
'The Colle is not a universal attacking formula. If Black controls e4 firmly or develops ...Bf5, White may need c4 and a different structure.',
'Compare with the London, where the bishop is developed to f4 first. Learn both to understand the cost and benefit of early bishop development.',[
('Classical Colle break','d4 d5 Nf3 Nf6 e3 e6 Bd3 c5 c3 Nc6 Nbd2 Bd6 O-O O-O e4 cxd4 cxd4', 'White executes the central break after development. Black resolves the c-file tension. The position becomes open enough that tactical calculation replaces slow setup moves.'),
('Zukertort system','d4 d5 Nf3 Nf6 e3 e6 Bd3 c5 b3 Nc6 O-O Bd6 Bb2 O-O Nbd2', 'White develops both bishops toward the center and kingside. The e4 break remains important, but the bishop on b2 adds long-diagonal pressure and changes the queenside structure.'),
('Against ...Bf5','d4 d5 Nf3 Nf6 e3 Bf5 c4 e6 Nc3 c6 Bd3 Bxd3 Qxd3 Nbd7 O-O', 'Black develops the bishop before closing the chain. White switches to c4 and a more open central game. This is a useful example of adapting the system to the opponent.'),
('Against a fianchetto','d4 Nf6 Nf3 g6 e3 Bg7 Bd3 O-O O-O d6 c4 Nbd7 Nc3 e5', 'White uses c4 to gain central space instead of insisting on c3. Black challenges the center with ...e5. The game has moved toward an Indian structure.')])

add('Trompowsky Attack','Systems and flank openings','Intermediate',
'White develops Bg5 immediately against ...Nf6, threatening to exchange bishop for knight and alter Black\'s pawns. The opening reduces some familiar Indian move orders but has independent tactical branches.',
'Decide whether Bxf6 creates a useful structure or simply gives Black the bishop pair. Develop the center and remaining pieces quickly after the early bishop move.',
'Challenge the bishop with ...Ne4, ...d5 or ...c5 and develop actively. If accepting doubled pawns, use the bishop pair and open files as compensation.',
'After Bxf6, Black may recapture with an e- or g-pawn, producing very different central and kingside structures. With ...Ne4, early piece moves can dominate the position.',
'Doubled pawns alone do not prove an advantage. White can spend too much time with the bishop; Black can chase it while neglecting the center.',
'The London and Colle are slower systems. The Trompowsky asks a concrete question on move two and needs separate preparation for each major reply.',[
('Main ...Ne4 response','d4 Nf6 Bg5 Ne4 Bf4 d5 e3 c5 Bd3 Qa5+ c3 cxd4 exd4 Nc6 Nf3 Bg4', 'Black gains time with the knight and a queen check. White develops and supports the center. The repeated bishop moves have a purpose, but they also give Black time for active play.'),
('...d5 with structural exchange','d4 Nf6 Bg5 d5 Bxf6 exf6 e3 Bd6 c4 dxc4 Bxc4 O-O Nc3 Nd7', 'White damages the pawn structure and then challenges the center. Black has the bishop pair and easy development. Assess the long-term pawn targets against current activity.'),
('...e6 system','d4 Nf6 Bg5 e6 e4 h6 Bxf6 Qxf6 Nc3 Bb4 Nf3 d6', 'White gains central space while Black recaptures with the queen. Black\'s queen is active but potentially exposed. White should finish development before trying to exploit it.'),
('...c5 counterplay','d4 Nf6 Bg5 c5 Bxf6 gxf6 d5 f5 Nc3 Bg7 e4 fxe4 Nxe4 d6', 'Black accepts doubled f-pawns but attacks the center and opens lines. White gains space and must coordinate the knights. The position is more dynamic than the pawn structure alone suggests.')])

add('English Opening','Systems and flank openings','Intermediate',
'White starts with c4, controlling d5 from the flank. The English can become a reversed Sicilian, a symmetrical structure or a transposition to a queen-pawn opening. The pawn center, not the first move, determines the plan.',
'Develop flexibly and decide whether to play d4, e4 or d3. Use the g2 bishop and queenside space when appropriate, but preserve enough central control to meet ...d5.',
'Choose a central structure early enough to coordinate development. Against a slow flank setup, seek ...d5 or ...e5 rather than allow White to dictate the center unopposed.',
'With c4/e4/d3, White creates a Botvinnik structure and accepts a hole on d4. Symmetrical c-pawns can lead to binds, open d-files or central pawn exchanges.',
'A reversed opening is not identical to the original with colors swapped: the extra tempo can change tactics and strategic choices. Do not copy a Sicilian line blindly.',
'The Reti and Catalan often transpose into English positions. Compare the actual central pawns and side to move before transferring a plan.',[
('Reversed Sicilian','c4 e5 Nc3 Nf6 g3 d5 cxd5 Nxd5 Bg2 Nb6 Nf3 Nc6 O-O Be7 d3', 'Black occupies the center while White develops against it. White has an extra tempo compared with some Sicilian structures, but still needs an active plan and control of d5.'),
('Symmetrical English','c4 c5 Nf3 Nf6 Nc3 Nc6 g3 g6 Bg2 Bg7 O-O O-O d4 cxd4 Nxd4', 'White breaks the symmetry by opening the center. Both fianchetto bishops become important. The resulting exchanges should be judged by activity rather than a desire to retain symmetry.'),
('Four Knights English','c4 e5 Nc3 Nf6 Nf3 Nc6 g3 Bb4 Bg2 O-O O-O e4 Ng5 Bxc3 bxc3', 'Black gains space and trades a bishop for structural changes. White must coordinate the displaced knight and use the bishop pair. The center is already concrete and cannot be handled by routine setup moves.'),
('Botvinnik structure','c4 e5 Nc3 Nc6 g3 g6 Bg2 Bg7 e4 d6 Nge2 Nge7 O-O O-O d3', 'White establishes c4/e4/d3 and controls d5 while leaving d4 weak. The knights and bishops must support the appropriate pawn break. Either flank can become active depending on the opponent\'s setup.')])

add('Reti Opening','Systems and flank openings','Intermediate',
'White begins with Nf3 and often c4, inviting Black to occupy the center before attacking it from the flank. The opening is flexible, but that flexibility requires recognizing transpositions and choosing a timely central commitment.',
'Develop the bishop on g2, pressure d5 and choose when to play d4 or d3. If Black advances d4, decide whether to undermine it with e3 or support a queenside blockade.',
'Occupy central space without overextending. Develop quickly and be ready for White\'s c4 and e3 breaks. If taking c4, avoid wasting time holding the pawn.',
'The advance ...d4 creates a space wedge for Black. A later d4 by White can transpose to the Catalan, Queen\'s Gambit or Indian structures.',
'Delaying the center is not the same as ignoring it. White can become cramped if Black gains space without pressure, and Black can overextend if the pawn wedge is unsupported.',
'Use the English and Catalan courses to recognize common destinations. A repertoire based on Nf3 needs answers to ...d5, ...Nf6 and ...c5.',[
('Reti accepted','Nf3 d5 c4 dxc4 e3 Nf6 Bxc4 e6 O-O a6 d4 c5 Nc3', 'White recovers the pawn while developing and later enters a Queen\'s Gambit Accepted structure. The transposition shows why central pawn recognition is more useful than memorizing names.'),
('Advance variation','Nf3 d5 c4 d4 e3 Nc6 exd4 Nxd4 Nxd4 Qxd4 Nc3 Nf6 d3', 'White undermines the advanced pawn and develops against the queen. Black has central activity but must finish development. The early exchanges remove the original pawn wedge.'),
('Double fianchetto','Nf3 d5 c4 e6 g3 Nf6 Bg2 Be7 O-O O-O b3 b6 Bb2 Bb7 e3', 'Both sides develop flexibly and keep the center unresolved. White should identify a useful d4 or cxd5 decision instead of making endless waiting moves.'),
('King s Indian transposition','Nf3 Nf6 c4 g6 g3 Bg7 Bg2 O-O O-O d6 d4 Nbd7 Nc3 e5', 'White commits d4 after castling and reaches a fianchetto King\'s Indian structure. The correct plans now come from that center, even though the game began as a Reti.')])

add('King s Indian Attack','Systems and flank openings','Foundation',
'White develops Nf3, g3, Bg2 and d3, often adding e4 and Nbd2. The setup can be used against several black centers, but the plans differ. Against a French-style structure, White may gain kingside space with e5; against ...e5, maneuvering is more typical.',
'Build the setup while watching the center, then choose a supported e5 or another useful break. Improve the knights and rooks before starting a kingside attack.',
'Gain central or queenside space and challenge White\'s slow development. Choose breaks according to the pawn center rather than assume White\'s setup can be ignored.',
'With e4/d3 against e6/d5, White may advance e5 and create a space wedge. Against e5/d6, the center is more symmetrical and requires a different plan.',
'The familiar attacking setup is not a forced mating pattern. If Black changes the center or keeps the king elsewhere, White must change plans.',
'Compare with the Closed Sicilian and King\'s Indian Defense. Reversed structures offer useful ideas, but the extra tempo and pawn commitments alter the details.',[
('Against the French structure','e4 e6 d3 d5 Nd2 Nf6 Ngf3 c5 g3 Nc6 Bg2 Be7 O-O O-O Re1 b5 e5', 'White advances e5 after completing development and Black gains queenside space. The opposing plans are clear, but the center and king safety still determine the attack\'s timing.'),
('Against the Sicilian','e4 c5 Nf3 e6 d3 Nc6 g3 d5 Nbd2 Nf6 Bg2 Be7 O-O O-O Re1', 'White keeps a restrained center and develops behind it. Black has central space and several exchanges available. White should prepare a break rather than assume e5 is always best.'),
('Against the Caro-Kann','e4 c6 d3 d5 Nd2 e5 Ngf3 Bd6 g3 Nf6 Bg2 O-O O-O Re8', 'Black occupies the center and develops comfortably. White\'s task is to create useful pressure with piece maneuvers and a well-timed central or flank break.'),
('Closed ...e5 structure','Nf3 Nf6 g3 g6 Bg2 Bg7 O-O O-O d3 d6 e4 e5 Nbd2 Nc6 Re1', 'The center is restrained and nearly symmetrical. White should improve pieces and calculate the appropriate pawn break. A French-style e5 attack cannot simply be transplanted here.')])

add('Bird s Opening','Systems and flank openings','Intermediate',
'White begins with f4, controlling e5 and creating an asymmetrical game. The opening resembles a Dutch with colors reversed, but Black has immediate central options. White\'s weakened king diagonal must be respected from the first move.',
'Develop Nf3 and the bishops, support central control and castle safely. Choose a Stonewall or fianchetto setup according to Black\'s center, not by habit.',
'Challenge the center with ...d5 or consider the sharp From Gambit with ...e5. Develop actively and exploit the weakened diagonal only when a concrete sequence supports it.',
'A White Stonewall uses f4/e3/d4/c3 and leaves e4 weak. A fianchetto setup keeps more central flexibility. The From Gambit opens the game immediately.',
'The f-pawn move exposes the e1-h4 diagonal. White must calculate checks and threats against h2 before taking more central pawns.',
'Compare with the Dutch and King\'s Gambit. The opening choice changes Black\'s responses, so a reversed setup is only a guide to ideas.',[
('Classical Bird','f4 d5 Nf3 Nf6 e3 g6 b3 Bg7 Bb2 O-O Be2 c5 O-O Nc6', 'White develops the queen bishop actively and keeps d3 or d4 available. Black occupies the center. White must turn control of e5 into useful piece play.'),
('Leningrad-style fianchetto','f4 d5 Nf3 g6 g3 Bg7 Bg2 Nf6 O-O O-O d3 c5 Qe1 Nc6', 'White supports a possible e4 break with the queen and bishop. Black has central space and can prevent or challenge it. The queen move should be judged by its central purpose.'),
('Stonewall setup','f4 d5 Nf3 Nf6 e3 e6 d4 c5 c3 Nc6 Bd3 Bd6 O-O O-O', 'White builds a fixed center and aims for e5 control. Black can exploit e4 and challenge the chain. The c1 bishop needs an eventual route into the game.'),
('From Gambit accepted','f4 e5 fxe5 d6 exd6 Bxd6 Nf3 g5 d4 g4 Ne5 Bxe5 dxe5 Qxd1+ Kxd1 Nc6', 'Black offers pawns to open attacking lines and White uses central play to simplify. The queens come off and White loses castling rights. Evaluate the resulting activity and material rather than assume a forced attack remains.')])
