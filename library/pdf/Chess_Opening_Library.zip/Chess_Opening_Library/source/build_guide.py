"""Collection guide and shared chess lessons. GPL-3.0-or-later."""
import json
from pathlib import Path
from xml.sax.saxutils import escape
import build_library as b

p=b.PDF(b.OUT/'00_Start_Here.pdf',dict(name='Start Here'),'Guide / 50 opening courses')
p.new('Chess Opening Library','50 openings, families and systems | Three course volumes each')
p.board(b.chess.Board(),63,624,300,'All boards are shown with White at the bottom')
p.section('A practical learning collection','Learn the ideas, explore the branches, then test your decisions. The green-and-cream vector boards and dark piece outlines follow the supplied example.pdf.',390,620,174)
p.section('What you will find','150 course PDFs, 202 annotated opening routes, 202 practice positions with answers, PGN files for replay, and a broader named-variation reference from the Lichess opening dataset.',48,274)
p.section('How the 50 were selected','This is a broad educational selection of important openings and common systems, not a measured top-50 popularity ranking. Large families such as the Sicilian are divided into separate courses. Directory numbers organize the library; they do not rank playing strength.',48,151)

for start,end in [(0,25),(25,50)]:
    p.new(f'Course index: {start+1:02d}-{end:02d}')
    y=672
    for i in range(start,end):
        c=b.COURSES[i];p.p(f'<b>{i+1:02d}</b>  '+escape(c['name']),48,y,367,11)
        p.p(escape(c['level']),445,y,119,9,color=b.MUTED);y-=21
    p.p('Every course folder contains 01 Foundations and Plans, 02 Annotated Variations, 03 Practice and Answers, Annotated_Lines.pgn, and Reference_Variations.pgn.',48,116,516,10)

p.new('A study method you can repeat')
y=674
for title,text in [
('1. Start with one route','Read the foundations and choose one branch that appeals to you. Replay the moves on a physical board or in a PGN viewer. Say what changes after each move: a threat, a controlled square, a pawn break or a piece improvement.'),
('2. Learn both sides','Write one useful plan for White and one for Black. An opening is easier to remember when you understand the opponent\'s counterplay. Memorizing only your own moves leaves you unprepared for deviations.'),
('3. Test from the diagram','Open Volume 3 before reading the answers. Identify the side to move, checks, material and structure. Choose two candidates and calculate at least four plies, including the opponent\'s reply.'),
('4. Play the position','Start practice games from the endpoint, switching colors. Use enough time to think. Review the first position where you could no longer explain the plan.'),
('5. Expand only where needed','Add a new branch when your games or curiosity demand it. You do not need to memorize all 50 courses to build a playable repertoire. A smaller set understood well is a better starting point.'),
('Suggested first sequence','Begin with the Italian, Four Knights, Caro-Kann, Queen\'s Gambit Declined and London. Then compare the French and Slav structures. Study the sharp Sicilians and gambits when you are comfortable calculating forcing lines.')]:y=p.section(title,text,48,y)

p.new('Read the moves and diagrams')
p.board(b.board_for('e4 e5 Nf3 Nc6 Bc4 Bc5'.split()),60,657,246,'A sample Italian position')
y=p.section('Coordinates','Files a-h run left to right; ranks 1-8 run bottom to top. The bottom-right square h1 is light. The caption under each board tells you whose turn it is.',350,657,214)
y=p.section('Piece letters','K king, Q queen, R rook, B bishop, N knight. A pawn move has no initial piece letter. White and Black use the same letters.',350,y,214)
p.section('Standard algebraic notation (SAN)','Nf3 means a knight moves to f3. Bxc6 means a bishop captures on c6. exd5 means the e-pawn captures on d5. A plus sign means check; # means checkmate. O-O is kingside castling and O-O-O is queenside castling. e8=Q promotes a pawn to a queen.',48,349)
p.section('Move numbers and disambiguation','1. e4 e5 gives White\'s first move and Black\'s reply. 6...Nf6 begins with Black\'s sixth move. Nbd2 identifies the knight from the b-file when two knights could legally move to d2. One ply is one player\'s move; four plies are two moves by each player.',48,217)
p.section('PGN and FEN','PGN stores games or variations for replay. FEN stores a position, including side to move and castling rights. Annotated_Lines.pgn contains the authored routes and engine continuations; Reference_Variations.pgn contains named reference positions.',48,121)

p.new('Opening principles that survive surprises')
y=674
for title,text in [
('Center','Control central squares with pawns and pieces. Occupation is useful only if it can be supported. A compact position can be sound if it has an active pawn break; a large center can be weak if it is attacked before development is complete.'),
('Development','Bring minor pieces into useful play, connect the rooks and avoid repeated moves without a reason. A move that gains a tempo on the queen is useful only if it also improves your position.'),
('King safety','Castle when it makes the king safer, not merely because it is available. When the center opens, checks and forcing moves become more important. Opposite-side castling often makes pawn advances more urgent, but the center can still decide the game.'),
('Tension','A capture changes files, diagonals and pawn targets. Before exchanging, compare the position after each legal recapture. Keeping tension can preserve options; releasing it can free your pieces.'),
('Tactical routine','Before every move, look for checks, captures and direct threats for both sides. Check whether a pinned piece can legally move. Then consider quiet improvements. Do not assume that a thematic sacrifice works in a slightly different position.'),
('Castling reminder','The king and relevant rook must retain castling rights, the path must be clear, and the king may not be in check or cross or land on an attacked square. A rook being attacked does not by itself forbid castling.')]:y=p.section(title,text,48,y)

def pair(title,a,z,first,second,shared):
    p.new(title)
    for idx,x in [(a,60),(z,336)]:
        c=b.COURSES[idx];l=c['branches'][0]
        p.board(b.board_for(l['moves'].split()),x,664,214,c['name'])
    y=p.section('First position',first,48,398)
    y=p.section('Second position',second,48,y)
    p.section('What to carry into your games',shared,48,y)

pair('Open centers and pawn activity',2,31,
'The Scotch opens the center early. Rooks and bishops can become active quickly, and an exposed king can be more important than a small pawn weakness.',
'The Queen\'s Gambit Accepted often leads to pressure on d4 and isolated-pawn possibilities after ...c5 and central exchanges. The exact diagram still contains central tension: do not label a pawn isolated until it has no friendly pawn on either adjacent file.',
'An isolated pawn lacks friendly pawns on neighboring files. The side with the isolated pawn often seeks active pieces and a central advance; the opponent often seeks a blockade and favorable exchanges. Neither plan is automatic.')
pair('Pawn chains and their bases',24,25,
'In the French Advance, Black attacks the base d4 with ...c5 and may attack the head e5 with ...f6. The c8 bishop initially sits behind the e6 pawn and needs a plan.',
'In the Caro-Kann Advance, Black often develops the c8 bishop outside the pawn chain before ...e6. A similar-looking center can therefore produce a different good-bishop/bad-bishop balance.',
'A pawn chain is a diagonal sequence of supporting pawns. Attack its base or undermine its support, but calculate the consequences of opening the center. A bishop restricted by its own pawns may improve after a timely pawn break or exchange.')
pair('Fianchetto centers: two different battles',34,37,
'The King\'s Indian often allows d5 to lock the center. White may work on the queenside while Black prepares ...f5. This division of plans depends on the center actually remaining closed.',
'The Grunfeld challenges d4 early with ...d5. Black often permits a large white center and attacks it with ...c5, the g7 bishop and active pieces. The resulting game is usually more open.',
'A fianchetto places a bishop on b2, g2, b7 or g7 behind a neighboring pawn. It is a piece arrangement, not a complete plan. The pawn center determines which diagonal is useful and which break frees the bishop.')
pair('Gambits: what counts as compensation?',7,8,
'The King\'s Gambit offers the f-pawn and changes king safety. White must justify the material with activity, central control or concrete tactics; Black can accept, decline or counterattack.',
'The Evans Gambit offers a queenside pawn to gain time against the bishop and establish a center. If Black returns material and completes development, White\'s initiative can fade.',
'Compensation may consist of development, open lines, a strong center or persistent pressure. State exactly which assets you have and how they can be used. A famous gambit name is not evidence that an attack must succeed.')

p.new('Build a small, connected repertoire')
y=674
for title,text in [
('As White with 1.e4','Choose one main approach against 1...e5, such as the Italian or Scotch. Then prepare separate responses to the Sicilian, French, Caro-Kann and other defenses. An Italian repertoire does not answer 1...c5.'),
('As White with 1.d4','Choose central play with c4 or a system such as the London. Still prepare for different black centers: ...d5, ...Nf6 and ...g6, ...f5, and early ...c5. A system reduces some memory demands but does not remove them.'),
('As Black','Choose one primary answer to 1.e4 and one to 1.d4. Add a plan against 1.c4 and 1.Nf3, noting possible transpositions. Prefer related pawn structures so that your study reinforces itself.'),
('Choose by the positions you enjoy','Quiet positions still require tactics, and sharp openings still require strategy. Use the training games to discover whether you prefer open files, fixed pawn chains, fianchetto pressure or long-term structural play.'),
('Keep an error notebook','Record the position, your candidate moves, the strongest reply you missed and the idea you want to remember. Review your own recurring mistakes before memorizing a new 20-move branch.'),
('What remains beyond this library','These courses are a broad learning survey. They do not contain every named branch, complete master-game collections or a fully specified response to every legal move. Use the reference PGNs and your own game analysis to extend the coverage.')]:y=p.section(title,text,48,y)

p.new('Sources, verification and sharing')
y=674
for title,text in [
('Original lessons','The explanatory prose, course organization and exercises were written for this collection. No commercial book or paid course was copied. The provided example.pdf was used as a visual reference for board design.'),
('Opening nomenclature','Named opening positions and reference PGNs come from the Lichess chess-openings dataset, released under CC0. The deepest recognized position along a route supplies its ECO/name label. Different names and move-order transpositions can refer to the same position.'),
('Chess validation','Every authored route is replayed with python-chess, checking legal moves, canonical SAN and valid positions. Diagrams and PGNs are generated from those same boards. Stockfish 18 screens the authored routes for substantial tactical errors and supplies sample continuations.'),
('Limits of engine checks','The analysis uses finite node budgets, not exhaustive proof. Candidate rankings can change with deeper searches; strategic prose has not received independent grandmaster review. Reference PGNs are checked for legality but are not recommendations and are not all engine-screened.'),
('Share and improve','The collection includes editable sources and license notices. The collection and builder are distributed under GPL-3.0-or-later; Cburnett artwork retains its GPLv2-or-later attribution, Lichess opening data is CC0, and bundled Noto fonts are under the SIL Open Font License.'),
('Where to start','Open README.md for the clickable course index, QUALITY_REPORT.md for the completed checks and their limits, and source/REBUILD.md to regenerate the collection. Keep the license and source files with the library when sharing.')]:y=p.section(title,text,48,y)
p.p('<link href="https://github.com/lichess-org/chess-openings">Lichess opening dataset</link> | <link href="https://stockfishchess.org/">Stockfish</link> | <link href="https://python-chess.readthedocs.io/">python-chess</link>',48,y,516,9,color=b.MUTED)
p.finish()
old=json.loads((b.OUT/'manifest.json').read_text());old=[x for x in old if x['path']!='00_Start_Here.pdf']
(b.OUT/'manifest.json').write_text(json.dumps(old+b.MANIFEST,indent=2))
for name,extra in [('layout_boxes.json',b.LAYOUT),('diagram_manifest.json',b.BOARDS)]:
    path=b.ROOT/name;old=json.loads(path.read_text());old=[r for r in old if r['pdf']!='00_Start_Here.pdf'];path.write_text(json.dumps(old+extra))
print('GUIDE',p.page,'pages')
