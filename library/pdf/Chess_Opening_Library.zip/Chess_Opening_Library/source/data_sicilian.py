from course_data import add

add('Sicilian Sveshnikov','Sicilian defenses','Advanced',
'Black drives the d4 knight with ...e5 after developing both knights. The opening accepts a backward d6 pawn and a hole on d5 for active pieces and central counterplay. Static weaknesses must be weighed against immediate activity.',
'Use d5 as an outpost, restrain ...d5 and complete development despite the displaced queenside knight. Decide whether exchanging on f6 helps control d5 enough to justify surrendering a bishop.',
'Gain space with ...b5, develop actively and seek ...f5 or ...d5 when supported. The bishop pair and open files can compensate for structural damage after Bxf6.',
'Black has d6 and e5 pawns; d5 is a permanent hole until a structural change occurs. After ...gxf6, the open g-file and doubled f-pawns create a different attacking balance.',
'Do not evaluate the position solely by the weak d5 square. A knight outpost is useful only if it can be occupied and supported without falling behind in activity.',
'Compare with Najdorf ...e5 structures. The Sveshnikov forces the d4 knight to b5 and creates concrete queenside moves that do not occur in every ...e5 Sicilian.',[
('Nd5 main structure','e4 c5 Nf3 Nc6 d4 cxd4 Nxd4 Nf6 Nc3 e5 Ndb5 d6 Bg5 a6 Na3 b5 Nd5 Be7 Bxf6 Bxf6 c3 O-O Nc2', 'White secures d5 and begins rerouting the a3 knight. Black has space and active bishops. The knight on c2 may support e3, but the route depends on Black\'s central play.'),
('Doubled f-pawns','e4 c5 Nf3 Nc6 d4 cxd4 Nxd4 Nf6 Nc3 e5 Ndb5 d6 Bg5 a6 Na3 b5 Bxf6 gxf6 Nd5 f5 Bd3 Be6', 'Black accepts damaged pawns and challenges the center with ...f5. White should not assume the black king is unsafe forever; active pieces and the center may provide compensation.'),
('Quiet seventh move','e4 c5 Nf3 Nc6 d4 cxd4 Nxd4 Nf6 Nc3 e5 Ndb5 d6 Nd5 Nxd5 exd5 Nb8 c4 Be7 Be2 O-O O-O', 'White simplifies the knight fight and establishes a pawn on d5. Black can prepare ...f5 while rerouting the b8 knight. The pawn outpost and knight outpost lead to different plans.'),
('Bishop retreat system','e4 c5 Nf3 Nc6 d4 cxd4 Nxd4 Nf6 Nc3 e5 Ndb5 d6 Bg5 a6 Na3 b5 Nd5 Be7 Bxf6 Bxf6 c4 b4 Nc2', 'White challenges Black\'s queenside space with c4. Black gains time by advancing b4. The central knight remains strong, but White must coordinate the other pieces around the expanded pawn structure.')])

add('Sicilian Taimanov','Sicilian defenses','Intermediate',
'Black uses ...e6 and ...Nc6 while delaying the g8 knight. This flexibility permits ...Qc7, ...a6 and several bishop arrangements. White must recognize when the game can transpose into a Scheveningen or a more independent Taimanov structure.',
'Develop actively and choose between Be3, Be2 and a fianchetto. Consider Nxc6 only after judging the effect of ...bxc6 on Black\'s central control.',
'Use the flexible knights and queen to pressure the center. Prepare ...d5 as a freeing break and avoid delaying king safety merely to preserve every option.',
'The e6 pawn supports ...d5 but restricts the c8 bishop. If Black recaptures on c6 with the b-pawn, the extra central pawn can help establish ...d5.',
'The queen on c7 can be exposed to Nb5. Check the b5 square before placing the queen or omitting ...a6.',
'Compare with the Kan: the Taimanov commits the b8 knight to c6, while the Kan often delays that commitment.',[
('Be3 and Qd2','e4 c5 Nf3 e6 d4 cxd4 Nxd4 Nc6 Nc3 Qc7 Be3 a6 Qd2 Nf6 O-O-O Bb4 f3', 'White prepares long castling and central support. Black pins the knight and contests e4. Tactical pressure on c3 is important because it is part of White\'s king shelter.'),
('Quiet Be2','e4 c5 Nf3 e6 d4 cxd4 Nxd4 Nc6 Nc3 Qc7 Be2 a6 O-O Nf6 Be3 Bb4 Na4', 'White develops with short castling and can challenge the bishop or queenside squares. Black uses piece pressure before committing the d-pawn.'),
('Fianchetto','e4 c5 Nf3 e6 d4 cxd4 Nxd4 Nc6 Nc3 Qc7 g3 a6 Bg2 Nf6 O-O Be7 Re1', 'The bishop on g2 adds central pressure. White keeps the position flexible; Black can choose ...d6 or aim directly for ...d5 if the tactics allow.'),
('Exchange on c6','e4 c5 Nf3 e6 d4 cxd4 Nxd4 Nc6 Nxc6 bxc6 Bd3 d5 O-O Nf6 Nc3 Be7', 'Black trades a structural concession for a broad center. White should pressure the central pawns without allowing them to advance freely. The open b-file can also become useful for Black.')])

add('Sicilian Kan','Sicilian defenses','Intermediate',
'Black plays ...e6 and ...a6 before developing the queenside knight. The setup prevents Nb5 and retains several development options. White can often build extra central space with c4 because the knight on b8 has not yet challenged d4.',
'Choose natural development with Bd3 or build a Maroczy-style bind with c4. Use the space to improve pieces before forcing exchanges.',
'Develop with ...Qc7, ...Nf6 and an appropriate knight route. Aim for ...d5 or ...b5 under favorable conditions, while keeping enough room for the c8 bishop.',
'A White c4/e4 bind restrains ...d5. Black often accepts less space but aims for well-timed pawn breaks and pressure against the center.',
'Flexibility has a cost: too many queen and pawn moves can leave Black behind in development. White should not overextend merely because Black is compact.',
'The Kan can transpose into Taimanov or Scheveningen positions. Check whether the b8 knight and d-pawn have actually committed before applying familiar plans.',[
('Bd3 development','e4 c5 Nf3 e6 d4 cxd4 Nxd4 a6 Bd3 Bc5 Nb3 Ba7 O-O Nc6 Nc3 Nf6', 'Black develops the bishop actively and induces a knight retreat. White castles and retains the center. The a7 bishop keeps an eye on the kingside diagonal.'),
('Maroczy bind','e4 c5 Nf3 e6 d4 cxd4 Nxd4 a6 c4 Nf6 Nc3 Qc7 Be2 b6 O-O Bb7', 'White controls d5 with two pawns. Black develops the bishop on b7 and waits for a favorable break. White\'s space advantage requires patient coordination rather than immediate aggression.'),
('Nc3 and Qc7','e4 c5 Nf3 e6 d4 cxd4 Nxd4 a6 Nc3 Qc7 Bd3 Nf6 O-O d6 f4 Be7', 'The position approaches a Scheveningen structure. White can prepare kingside play; Black retains ...b5 and central counterplay. Exact queen placement changes the tactics.'),
('Be2 system','e4 c5 Nf3 e6 d4 cxd4 Nxd4 a6 Be2 Nf6 Nc3 Bb4 O-O Nc6 Nxc6 bxc6', 'Black develops with a pin and may obtain a stronger central pawn mass after the knight exchange. White should examine whether the doubled c-pawns can actually be attacked.')])

add('Accelerated Dragon','Sicilian defenses','Intermediate',
'Black fianchettoes the bishop before playing ...d6, hoping to achieve ...d5 in one move. That saved tempo is the point of the opening. White can answer with the Maroczy Bind, a setup unavailable in the same way in many ordinary Dragon move orders.',
'Choose c4 to restrain ...d5 or develop rapidly with Nc3 and Bc4. Before castling long, check whether Black can immediately open the center.',
'Use the g7 bishop and the option of ...d5. Against the bind, maneuver patiently and prepare a freeing break rather than forcing one before the pieces are ready.',
'The c4/e4 bind creates a space advantage for White but leaves central squares for blockading pieces. Without c4, Black may free the game with a single ...d5 advance.',
'Do not copy the Yugoslav Attack mechanically. The absence of ...d6 can allow ...d5 before White\'s pawn attack becomes dangerous.',
'Study alongside the Dragon and English Symmetrical structures. Similar bishops do not mean identical pawn-break timing.',[
('Maroczy main setup','e4 c5 Nf3 Nc6 d4 cxd4 Nxd4 g6 c4 Bg7 Be3 Nf6 Nc3 O-O Be2 d6 O-O Bd7', 'White establishes the bind before developing the queenside knight. Black accepts a compact position and prepares coordinated counterplay. The d5 square is the strategic reference point.'),
('Bc4 development','e4 c5 Nf3 Nc6 d4 cxd4 Nxd4 g6 Nc3 Bg7 Be3 Nf6 Bc4 O-O Bb3 d6 f3', 'Bc4 makes a direct ...d5 harder, and Black settles into a Dragon-type structure with ...d6. White should still verify the exact move order before starting a kingside attack.'),
('Exchange variation of the bind','e4 c5 Nf3 Nc6 d4 cxd4 Nxd4 g6 c4 Bg7 Be3 Nf6 Nc3 O-O Be2 Nxd4 Bxd4 d6', 'Black trades a pair of knights to reduce the space disadvantage. White keeps central control and the bishop pair remains on the board. Exchanges are a tool for freeing the position.'),
('Hyperaccelerated route','e4 c5 Nf3 g6 d4 cxd4 Nxd4 Bg7 c4 Nc6 Be3 Nf6 Nc3 O-O Be2 d6', 'Black reaches the bind through an earlier fianchetto. This route has independent sidelines before d4, but the final structure is familiar once all pieces match.')])

add('Sicilian Scheveningen','Sicilian defenses','Advanced',
'Black builds the compact d6/e6 center and keeps the minor pieces flexible. The structure is resilient but can invite a direct kingside attack. The timing of White\'s g-pawn advance is a major move-order issue.',
'Use space to prepare f4-f5 or e4-e5, but coordinate pieces and king safety first. Against a direct Scheveningen move order, study the Keres Attack with g4.',
'Complete development, resist premature central advances, and seek ...d5 or ...b5 when supported. Exchange attacking pieces when doing so does not surrender the center.',
'The d6/e6 pawns control central entry squares while leaving d5 available as a freeing break. If White advances e5, the structure can become locked or open depending on the exchanges.',
'The Keres Attack is not the same as playing g4 in any Sicilian. Black\'s move order and piece placement determine whether the advance is strong or simply weakening.',
'Many Najdorf positions become Scheveningen structures after ...e6. The inserted ...a6 changes the attack and must be included in calculations.',[
('Keres Attack','e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 e6 g4 h6 h4 Nc6 Rg1 d5 exd5 Nxd5', 'White gains kingside space before castling. Black challenges the center to make the flank attack less comfortable. The rook on g1 belongs to a concrete attacking plan, not ordinary development.'),
('Classical setup','e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 e6 Be2 Be7 O-O O-O f4 a6 Be3 Qc7', 'White builds attacking potential behind a secure king. Black coordinates before choosing a break. The e5 advance is often more important than a speculative piece sacrifice.'),
('English-style attack','e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 e6 Be3 a6 f3 b5 Qd2 Nbd7 g4 h6', 'White supports e4 and prepares long castling; Black gains queenside space. Since both kings are still in the center at the endpoint, opening files requires special care.'),
('Fianchetto restraint','e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 e6 g3 Nc6 Bg2 Be7 O-O O-O Be3', 'White develops without an immediate pawn storm and pressures the center from g2. Black has a solid setup but still needs active plans rather than permanent waiting.')])

add('Alapin Sicilian','Anti-Sicilians','Foundation',
'White plays c3 to support a broad center with d4. The opening avoids many Open Sicilian branches but gives Black immediate central counterplay. Because c3 is occupied by a pawn, the queenside knight cannot develop there at once.',
'Build d4 when possible and develop without overdefending the pawn center. If exchanges produce an isolated d-pawn, use active pieces and the open files to justify it.',
'Challenge the center with ...d5 or ...Nf6. Develop with tempo against advanced pawns and avoid granting White an ideal center without resistance.',
'The main choices lead to an isolated d-pawn, an advanced e5 pawn, or an early queen exchange. Each structure requires a different plan.',
'Do not judge the Alapin by whether White gets two center pawns. The important question is whether those pawns survive with active piece support.',
'The isolated-pawn positions connect to the Panov Caro-Kann and Queen\'s Gambit Accepted. Learn the shared structure once, then note the different pieces.',[
('Main ...Nf6 system','e4 c5 c3 Nf6 e5 Nd5 d4 cxd4 Nf3 Nc6 cxd4 d6 exd6 Qxd6 Nc3', 'White gains time against the queen and develops toward an isolated-pawn structure. Black has challenged the center before White could finish development.'),
('Main ...d5 system','e4 c5 c3 d5 exd5 Qxd5 d4 Nf6 Nf3 e6 Be2 Nc6 O-O cxd4 cxd4', 'White accepts an isolated d-pawn in exchange for development and space. Black aims to blockade d5 and exchange active pieces when appropriate.'),
('Advance structure','e4 c5 c3 Nf6 e5 Nd5 d4 e6 Nf3 d6 exd6 Bxd6 dxc5 Bxc5', 'Black frees the bishop and reduces the center. White should continue development instead of treating the vanished central space as a failure of the opening.'),
('French transposition','e4 c5 c3 e6 d4 d5 e5 Nc6 Nf3 Qb6 Be2 cxd4 cxd4 Nge7', 'The position becomes a French Advance structure. Black attacks d4 and White supports the pawn chain. The correct plans follow the structure regardless of the starting move order.')])

add('Closed Sicilian','Anti-Sicilians','Foundation',
'White delays d4, develops Nc3 and often fianchettoes the king bishop. The center stays closed longer, allowing maneuvering and flank plans. Black normally gains queenside space while White considers kingside expansion.',
'Develop Bg2, d3 and a suitable kingside knight. Prepare f4 with enough support and decide whether to open the center or keep it closed before pushing more pawns.',
'Use ...g6 and ...Bg7 or an ...e6 setup, develop smoothly and prepare queenside play. Keep central ...d5 ideas available rather than responding only on the flank.',
'White\'s e4/d3 center leaves d4 unoccupied. The breaks f4-f5, ...b5-b4 and ...d5 determine which wing opens first.',
'A closed center is not permanently closed. A premature flank attack can fail if Black opens d5 with tempo against the king.',
'Compare with the King\'s Indian Attack and reversed English positions. Extra tempos do not remove the need to calculate central breaks.',[
('Main fianchetto','e4 c5 Nc3 Nc6 g3 g6 Bg2 Bg7 d3 d6 Be3 e6 Qd2 Nge7 Nge2 O-O O-O', 'White develops the queen and bishop before choosing the pawn attack. Black supports d5 and can expand on the queenside. Both sides retain central options.'),
('f4 system','e4 c5 Nc3 Nc6 g3 g6 Bg2 Bg7 d3 d6 f4 e6 Nf3 Nge7 O-O O-O', 'White claims kingside space while Black prepares flexible counterplay. The e4 pawn and e3 square can become sensitive after further pawn advances.'),
('Early ...d5','e4 c5 Nc3 e6 g3 d5 exd5 exd5 Bg2 Nf6 d3 Be7 Nge2 O-O O-O', 'Black opens the center before a typical closed setup is complete. White\'s bishop is active, but the game is no longer a slow pawn race. Reevaluate the files and central targets.'),
('Queen development','e4 c5 Nc3 Nc6 g3 g6 Bg2 Bg7 d3 d6 Be3 e6 Qd2 Nd4 Nd1', 'Black establishes a knight on d4 and White considers exchanging or challenging it. A retreat such as Nd1 must serve a clear purpose because it temporarily reduces development.')])

add('Grand Prix Attack','Anti-Sicilians','Intermediate',
'White plays f4 without opening the center with d4. The plan often includes Nf3, Bc4 or Bb5 and kingside pressure. Black can meet the attack by challenging the center and restricting the active bishop.',
'Support e4, develop Nf3 and castle before committing to Qe1-h4 or f5. Choose the bishop square according to Black\'s pawn structure.',
'Use ...g6 and ...Bg7 or ...e6 with ...d5. Challenge White\'s center and avoid unnecessary weaknesses near the king.',
'The e4/f4 pawn pair gives space but weakens e3 and the e1-h4 diagonal. Black\'s central break can force White to abandon a planned flank attack.',
'The queen maneuver Qe1-h4 is a plan, not a forced attack. Before using it, check the center and whether Black can gain time on the bishop.',
'The Closed Sicilian uses similar pieces but often delays f4. Learn why the bishop belongs on b5 in some structures and c4 in others.',[
('Bb5 against the fianchetto','e4 c5 Nc3 Nc6 f4 g6 Nf3 Bg7 Bb5 Nd4 O-O Nxb5 Nxb5 d6 d3 Nf6', 'White exchanges the attacking bishop for Black\'s queenside knight and gains a different structural battle. The remaining pieces must carry the attack; do not assume the bishop pressure still exists.'),
('Bc4 attacking setup','e4 c5 Nc3 Nc6 f4 g6 Nf3 Bg7 Bc4 e6 O-O Nge7 d3 O-O Qe1', 'White prepares queen activity on the kingside. Black has a solid center and can consider ...d5. The queen move is useful only if the center remains under control.'),
('Early f4 and ...d5','e4 c5 f4 d5 exd5 Nf6 Bb5+ Bd7 Bxd7+ Nbxd7 c4 e6 dxe6 fxe6', 'Black challenges White before Nc3 has been played. The position becomes an open central contest, demonstrating why the early f4 move order needs independent preparation.'),
('...e6 setup','e4 c5 Nc3 e6 f4 d5 Nf3 dxe4 Nxe4 Nc6 Bb5 Bd7 O-O Nf6', 'Black opens the center and develops naturally. White should use active pieces and king safety rather than insist on a closed-position pawn storm.')])

add('Rossolimo and Moscow Sicilians','Anti-Sicilians','Intermediate',
'White develops Bb5 against ...Nc6 (Rossolimo) or gives Bb5+ against ...d6 (Moscow). These systems reduce the need for Open Sicilian theory while retaining strategic tension. The presence or absence of check is a major difference.',
'Decide whether to exchange on c6 or preserve the bishop. Develop efficiently, support the center and use any structural targets created by the exchange.',
'In the Rossolimo, choose a recapture that fits the intended center. In the Moscow, interpose a piece and develop without letting the check disrupt coordination.',
'Rossolimo exchanges can give Black doubled c-pawns and the bishop pair. Moscow exchanges often remove a pair of bishops and lead to flexible central structures.',
'Do not confuse Bb5 with Bb5+. A line that uses the forcing nature of check in the Moscow may not work in the Rossolimo.',
'These systems are responses to specific Sicilian move orders. Against ...e6, White needs a separate choice, covered in the Kan and Taimanov courses.',[
('Rossolimo with ...g6','e4 c5 Nf3 Nc6 Bb5 g6 Bxc6 dxc6 d3 Bg7 h3 Nf6 Nc3 O-O Be3', 'White exchanges the bishop for structural targets. Black uses the bishop pair and active central control. The doubled pawns may support useful squares rather than become immediate weaknesses.'),
('Rossolimo with ...e6','e4 c5 Nf3 Nc6 Bb5 e6 O-O Nge7 Re1 a6 Bf1 d5 exd5 Nxd5', 'White preserves the bishop and supports e4. Black opens the center with active piece play. The bishop retreat is purposeful because it retains options on a changed diagonal.'),
('Moscow, bishop interposition','e4 c5 Nf3 d6 Bb5+ Bd7 Bxd7+ Qxd7 O-O Nf6 Re1 Nc6 c3 e6 d4', 'The bishop exchange simplifies development without removing central tension. White prepares d4 under favorable conditions. Black must decide how to meet the central break.'),
('Moscow, knight interposition','e4 c5 Nf3 d6 Bb5+ Nd7 d4 cxd4 Qxd4 Nf6 O-O a6 Bxd7+ Bxd7 c4', 'White builds central space after the queen recapture. Black develops with tempo and seeks activity. The resulting c4/e4 setup resembles a bind but comes with a different queen placement.')])
