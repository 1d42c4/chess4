# Rebuild the library

The editable course prose and authored SAN lines are in `course_data.py` and the `data_*.py` files. `all_courses.py` assembles the 50 courses. `build_library.py` draws vector boards and writes the course PDFs/PGNs; `build_guide.py` writes the introductory guide.

Use Python 3.12 or newer in a virtual environment. Install the listed packages:

```text
python -m pip install -r requirements.txt
python check_lines.py
python build_library.py
python build_guide.py
```

Run these commands from the `source` directory. The default output is the sibling `rebuilt` directory. The included Noto fonts are used automatically. The existing PDFs are left intact. You can set `CHESS_OUTPUT` to another destination; if you do, adjust the QA script's OUT location to the same destination.

The cached Stockfish results are included, so rebuilding the unchanged courses does not require an engine download or network access. If you edit an opening line, regenerate its analysis before building. Install Stockfish separately from https://stockfishchess.org/download/ and set `STOCKFISH_EXECUTABLE` to the executable path, then run:

```text
python analyze.py
python build_library.py
python build_guide.py
```

The engine executable is intentionally not bundled. The analysis script uses Windows process flags; on another operating system replace `creationflags=0x08000000` with `creationflags=0` before running it. Cached PDF generation does not need that change.

For verification, install Poppler so that `pdftoppm` is on PATH. Run `python qa_library.py --render` after both builders. On a non-Windows system change the same process flag in the QA script. The script checks every PDF's text/pages, the recorded layout rectangles, all diagram FENs and all exported PGN variations. It also renders all pages and creates contact sheets.

`engine_cache.json` stores exact positions, scores, principal variations, depths and node counts. `verification/` records the delivered build's checks and diagram positions. The five TSV files in `assets/` are the exact Lichess CC0 source snapshot used here. Piece SVG sources are in `piece_artwork/`; the builder obtains identical base artwork from the pinned python-chess version and applies the sample's dark-outline colors.

Rendered PDFs need not be byte-identical between rebuilds because PDF timestamps and dependency versions may vary. Re-running engine searches may also change results because the search uses two threads. Keep the supplied cache to reproduce the printed continuations.
