from course_data import add

add('Bishop s Opening','Open games','Foundation',
'White develops Bc4 before Nf3, leaving the f-pawn free and keeping several transpositions available. The opening is useful for learning flexible development, but Black can often equalize central space with ...d5.',
'Support e4 with d3 or Nc3, develop the knights and choose the king\'s destination. Consider f4 only after assessing the open diagonal toward the king.',
'Use ...Nf6 to pressure e4 and prepare ...d5. Against a quiet setup, finish development and contest central squares without chasing the bishop unnecessarily.',
'A quiet d3/e4 center resembles the Italian, but the f-pawn may remain mobile. Early ...d5 can force exchanges and remove White\'s active bishop.',
'An attack on f7 is not a threat unless it is supported by a concrete sequence. Do not sacrifice just because the bishop points at the king.',
'Compare the Italian and Vienna courses; many positions transpose after the knights develop.',[
('Quiet system','e4 e5 Bc4 Nf6 d3 Bc5 Nf3 Nc6 c3 d6 O-O O-O', 'White reaches a familiar Italian structure by a different move order. Once the positions coincide, apply the same central plans and do not invent differences based on the opening name.'),
('Vienna route','e4 e5 Bc4 Nc6 Nc3 Nf6 d3 Bc5 Nf3 d6 O-O O-O', 'Nc3 develops quickly but blocks c3. White must find another way to support a future d4, or maintain the closed center and improve the pieces.'),
('Urusov Gambit','e4 e5 Bc4 Nf6 d4 exd4 Nf3 Nxe4 Qxd4 Nf6 Nc3 Nc6 Qh4 Be7', 'White offers a pawn for development and pressure along open lines. Black can defend by developing and limiting queen activity. This is a gambit branch, not the quiet Bishop\'s Opening.'),
('Immediate central challenge','e4 e5 Bc4 Nf6 d3 d5 exd5 Nxd5 Nf3 Nc6 O-O Be7 Re1 O-O', 'Black obtains central space and neutralizes some bishop pressure. White develops into an open position. The center has changed, so slow closed-game plans may no longer fit.')])

add('Danish Gambit and Center Game','Open games','Intermediate',
'White opens the center with d4 immediately. Recapturing with the queen creates the Center Game; offering c3 creates the Danish Gambit. These related choices teach the difference between central development and sacrificing pawns for open diagonals.',
'In the Center Game, retreat the queen to a safe square and develop. In the Danish, use the bishop pair and open lines quickly; be willing to recover material when the initiative fades.',
'Develop with tempo against the queen, or return a gambit pawn with ...d5 to free the position. A successful defense values king safety more than retaining every extra pawn.',
'The Danish can remove White\'s b- and c-pawns while placing bishops on b2 and c4. The Center Game retains more pawns but exposes the queen to tempo attacks.',
'The fully accepted Danish contains simplifying counterplay based on ...d5. Do not teach the opening as a forced attack against best defense.',
'The Scotch Gambit delays the c-pawn sacrifice and can transpose to related positions. Compare the cost of queen activity with the cost of sacrificed pawns.',[
('Center Game','e4 e5 d4 exd4 Qxd4 Nc6 Qe3 Nf6 Nc3 Bb4 Bd2 O-O O-O-O Re8', 'The queen supports central play but has already moved twice. Opposite-side castling gives both sides attacking chances. Development and open files now matter more than opening labels.'),
('Danish, one pawn offered','e4 e5 d4 exd4 c3 dxc3 Nxc3 Nc6 Nf3 Bb4 Bc4 d6 O-O Nf6', 'White recaptures with the knight and offers one pawn for development. Black develops with a pin and can seek exchanges. White needs activity, not just a lead in the count of developed pieces.'),
('Danish, fully accepted','e4 e5 d4 exd4 c3 dxc3 Bc4 cxb2 Bxb2 d5 Bxd5 Nf6 Bxf7+ Kxf7 Qxd8 Bb4+ Qd2 Bxd2+ Nxd2', 'The central counterstrike produces a famous simplifying sequence. Black returns material and the queens disappear. Follow the move order exactly: this is a tactical illustration, not a promise that Black must play it.'),
('Declined with d5','e4 e5 d4 exd4 c3 d5 exd5 Qxd5 cxd4 Nc6 Nf3 Bg4 Be2 O-O-O', 'Black declines the extended pawn hunt and develops actively. The central pawn exchanges alter the open files. White should complete development rather than try to reproduce accepted-gambit attacks.')])

add('Sicilian Najdorf','Sicilian defenses','Advanced',
'After the Open Sicilian, Black plays ...a6 to control b5 and keep the central pawn structure flexible. The Najdorf contains both positional systems and forcing attacks. It requires a specific response to White\'s sixth move.',
'Choose a coherent setup: Be3 with f3 and Qd2, the sharper Bg5, or a quieter Be2. Coordinate the intended central or kingside break with the location of your king.',
'Use ...a6 to support queenside expansion and decide between ...e5 and ...e6. Develop before starting a pawn race, and react to White\'s exact attacking arrangement.',
'After ...e5, d5 becomes an important outpost and Black may have a backward d6 pawn. With ...e6, the structure is more flexible but can restrict the c8 bishop.',
'Do not mix move orders from unrelated Najdorf branches. A routine ...e5 against one setup can be inaccurate against another, and opposite-side castling magnifies the cost of a lost tempo.',
'The Scheveningen and Najdorf frequently overlap after ...e6. The Najdorf\'s inserted ...a6 can both help queenside play and cost a defensive tempo.',[
('English Attack','e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 a6 Be3 e5 Nb3 Be6 f3 Be7 Qd2 O-O O-O-O Nbd7', 'White prepares g4 while Black develops and eyes queenside counterplay. Black\'s d5 weakness must be balanced against active pieces. Opposite-side castling requires concrete calculation before every pawn push.'),
('Bg5 main structure','e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 a6 Bg5 e6 f4 Be7 Qf3 Qc7 O-O-O Nbd7', 'White increases pressure on f6 and the kingside. Black retains the e6/d6 structure and coordinates the queen with the c-file. Tactical details decide whether exchanges help the attacker or defender.'),
('Classical Be2','e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 a6 Be2 e5 Nb3 Be7 O-O O-O Be3 Be6', 'Both sides castle short and the struggle centers on d5 and pawn breaks. White aims to use the outpost; Black seeks active pieces and ...d5 when possible.'),
('Fianchetto system','e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 a6 g3 e5 Nde2 Be7 Bg2 O-O O-O b5', 'White develops the bishop toward the center and avoids the most forcing attacks. Black gains queenside space. The knight retreat makes d5 and f4 useful squares to examine.')])

add('Sicilian Dragon','Sicilian defenses','Advanced',
'Black fianchettoes the king bishop behind a d6 pawn. The bishop on g7 is the organizing piece, especially on the long diagonal. Opposite-side castling often leads to direct attacks in which one tempo can change the result.',
'In the Yugoslav Attack, coordinate Be3, f3, Qd2 and queenside castling, then assess the timing of h4-h5. In quieter systems, restrict Black\'s bishop and control d5.',
'Activate the g7 bishop, use the c-file and seek central ...d5 breaks when justified. Coordinate counterplay against the white king instead of making unrelated defensive pawn moves.',
'The d6/e7 pawns leave d5 as a central break square. Exchanges on c3 can damage White\'s king shelter but must be justified by concrete compensation.',
'The exchange sacrifice ...Rxc3 is thematic, not automatic. Count the attacking pieces and calculate White\'s best defense before giving a rook for a knight.',
'The Accelerated Dragon delays ...d6, aiming for ...d5 in one move; this changes White\'s available systems and the pace of the attack.',[
('Yugoslav with Bc4','e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 g6 Be3 Bg7 f3 O-O Qd2 Nc6 Bc4 Bd7 O-O-O Rc8 Bb3', 'Bc4 restrains ...d5 and joins the attack. Black places the rook on the semi-open c-file. White retreats the bishop before it can be hit with tempo.'),
('Yugoslav, early castling','e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 g6 Be3 Bg7 f3 O-O Qd2 Nc6 O-O-O d5 exd5 Nxd5 Nxc6 bxc6', 'Black breaks in the center immediately. The resulting pawn structure and open lines differ from the Bc4 branch. Memorizing h4 ideas without checking ...d5 is a common mistake.'),
('Classical Dragon','e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 g6 Be2 Bg7 O-O O-O Be3 Nc6 Nb3 Be6 f4', 'White castles short and builds central control. The game is less of a direct pawn race, but the g7 bishop and d5 break remain central to both plans.'),
('Fianchetto against fianchetto','e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 g6 g3 Bg7 Bg2 O-O O-O Nc6 Nde2 Rb8', 'Both bishops influence the long diagonals. Black can prepare queenside space while White keeps central flexibility. Evaluate exchanges of the fianchetto bishops carefully.')])

add('Classical Sicilian','Sicilian defenses','Advanced',
'Black develops both knights to natural squares and keeps several bishop setups available. White\'s sixth move determines whether the game becomes a sharp Richter-Rauzer, a Sozin attack, or a quieter positional contest.',
'Use Bg5 to pressure f6 and support a central attack, or Bc4 to aim at e6 and f7. Develop with a clear king-safety plan because the center may open abruptly.',
'Coordinate the knights, challenge the central d4 knight and choose ...e6 or ...g6 according to White\'s setup. Seek ...d5 as an equalizing break when it works tactically.',
'An e6/d6 center often leaves a backward d6 pawn but controls key central squares. After exchanges on f6 or c6, structural weaknesses may be offset by the bishop pair or open files.',
'Against Bg5, the pin can change whether ...d5 or ...Nxe4 works. Do not copy a Dragon setup without checking the tactical consequences of White\'s bishop placement.',
'This is a bridge between the Scheveningen, Dragon and Najdorf, but each move order allows different attacks.',[
('Richter-Rauzer','e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 Nc6 Bg5 e6 Qd2 Be7 O-O-O O-O f4 Nxd4 Qxd4', 'White castles long and supports e5. Black exchanges the central knight to reduce pressure and then seeks counterplay. The queen on d4 can be active but may become a target.'),
('Sozin development','e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 Nc6 Bc4 e6 Be3 Be7 Bb3 O-O O-O', 'The bishop on b3 keeps pressure along the diagonal while stepping away from ...d5 attacks. Black must balance the freeing break with the vulnerability of e6.'),
('Quiet Be2 system','e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 Nc6 Be2 e5 Nb3 Be7 O-O O-O Be3', 'Black gains central space but leaves d5 available. White aims for control of that square and pressure on d6. The structural tradeoff resembles other ...e5 Sicilians.'),
('Fianchetto system','e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 Nc6 g3 g6 Bg2 Bg7 O-O O-O Nde2', 'The position transposes toward a Dragon with White\'s bishop on g2. The knight retreat preserves flexibility and avoids exchanges that might help Black free the position.')])
