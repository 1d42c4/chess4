from course_data import add

add('French Defense','Other defenses to e4','Intermediate',
'Black supports ...d5 with ...e6 and challenges White\'s center. The French teaches pawn chains, counterattacks against their base and the problem of a restricted light-square bishop. The Advance, Exchange, Tarrasch and Nc3 systems create genuinely different positions.',
'With e5, use space to develop and attack while defending d4. In open structures, prioritize activity rather than trying to preserve a closed-position attacking plan.',
'Attack the chain with ...c5 and sometimes ...f6. Find work for the c8 bishop through exchanges or a suitable development route. Time the central breaks to match piece readiness.',
'The typical chain is White d4/e5 against Black d5/e6. Black attacks d4 with ...c5; ...f6 attacks e5. The Exchange removes the e-pawns and opens the game.',
'The closed center does not justify neglecting development. White can lose d4 while attacking on the wing; Black can open ...f6 before the king is ready.',
'The Advance Caro-Kann resembles the pawn chain but develops the c8 bishop outside it. Compare the bishop placement before transferring plans.',[
('Advance variation','e4 e6 d4 d5 e5 c5 c3 Nc6 Nf3 Qb6 a3 c4 Nbd2 Na5', 'Black fixes the queenside with ...c4 instead of resolving the center immediately. White has more room on the kingside, but the queenside pawn structure now determines several knight routes.'),
('Exchange variation','e4 e6 d4 d5 exd5 exd5 Nf3 Nf6 Bd3 Bd6 O-O O-O Re1 Re8', 'The symmetrical pawn structure is open enough for active piece play. A useful plan is to improve the least active piece and time c4 or ...c5 rather than manufacture an attack without targets.'),
('Tarrasch variation','e4 e6 d4 d5 Nd2 c5 exd5 exd5 Ngf3 Nc6 Bb5 Bd6 O-O Ne7', 'Nd2 avoids the Winawer pin but temporarily blocks the c1 bishop. Black challenges d4 immediately. Exchanges can produce an isolated d-pawn with active pieces.'),
('Winawer, positional branch','e4 e6 d4 d5 Nc3 Bb4 e5 c5 a3 Bxc3+ bxc3 Ne7 Nf3 b6 a4 Ba6', 'Black trades a bishop for structural damage and later exchanges the restricted c8 bishop. White gains the bishop pair and attacking chances. The doubled c-pawns also reinforce d4.'),
('Classical, Steinitz setup','e4 e6 d4 d5 Nc3 Nf6 e5 Nfd7 f4 c5 Nf3 Nc6 Be3 Be7 Qd2 O-O', 'White builds a large center and develops behind it. Black attacks its base and seeks timely exchanges. The extra space is useful only while White can maintain the center safely.')])

add('Caro-Kann Defense','Other defenses to e4','Foundation',
'Black supports ...d5 with ...c6, keeping the c8 bishop free to develop before ...e6. The defense is a useful study of sound pawn structures and patient counterplay. White can choose space, simplification or an isolated-pawn battle.',
'In the Advance, use the extra space without allowing Black\'s bishop to become too comfortable. In the Panov, use piece activity to compensate for an isolated d-pawn.',
'Develop the light-square bishop actively, then support the center and complete development. Use ...c5 or ...e5 when the pieces can support the break.',
'Advance positions resemble the French but with Black\'s bishop outside the chain. Exchange and Panov structures are more open, with different pawn targets.',
'Do not push ...c5 merely because it is thematic if d5 becomes tactically vulnerable. White should avoid chasing the bishop with pawns while falling behind in development.',
'The Panov connects directly to Queen\'s Gambit and Alapin isolated-pawn positions. The Advance is best compared with the French Advance.',[
('Advance, short system','e4 c6 d4 d5 e5 Bf5 Nf3 e6 Be2 c5 O-O Nc6 Be3 cxd4 Nxd4', 'Black frees the position with ...c5 while White develops calmly. The exchange on d4 reduces the pawn chain and creates a more open piece battle.'),
('Classical main line','e4 c6 d4 d5 Nc3 dxe4 Nxe4 Bf5 Ng3 Bg6 h4 h6 Nf3 Nd7 h5 Bh7 Bd3 Bxd3 Qxd3', 'White gains kingside space and exchanges the active bishop. Black has a sound structure but must finish development. The advanced h-pawn can be both an attacking asset and an endgame target.'),
('Panov-Botvinnik Attack','e4 c6 d4 d5 exd5 cxd5 c4 Nf6 Nc3 e6 Nf3 Bb4 cxd5 Nxd5 Bd2 O-O', 'White opens the center and accepts isolated-pawn possibilities. Black pins the knight and prepares a blockade. Both sides must balance structural considerations against immediate tactics.'),
('Exchange development','e4 c6 d4 d5 exd5 cxd5 Bd3 Nc6 c3 Nf6 Bf4 Bg4 Qb3 Qd7 Nd2', 'White develops the bishops actively and pressures b7. Black counters with a pin and protects the queenside. The pawn structure is relatively stable, so piece coordination is the main task.')])

add('Scandinavian Defense','Other defenses to e4','Foundation',
'Black challenges e4 immediately with ...d5. After the pawn exchange, Black either recaptures with the queen or develops a knight before recovering the pawn. The main practical issue is completing development despite early queen moves.',
'Develop with tempo on the queen and occupy the center with d4. Gain useful time rather than chasing the queen with moves that weaken your position.',
'Choose a queen retreat or the ...Nf6 approach, then develop solidly with ...c6 and ...Bf5 or ...Bg4 as appropriate. Avoid repeated queen adventures.',
'Many queen-recapture lines produce a c6/e6 shell with a white pawn on d4. The ...Nf6 branch can generate a more open gambit structure.',
'Attacking the queen is useful only if the attacking move improves your position. Black must calculate discovered attacks and pins when the queen remains near the center.',
'Compare Caro-Kann structures: the Scandinavian can reach a similar pawn shell, but Black has spent time moving the queen.',[
('Queen to a5','e4 d5 exd5 Qxd5 Nc3 Qa5 d4 Nf6 Nf3 c6 Bc4 Bf5 Bd2 e6 Qe2', 'The queen stays active and can pressure c3. White develops toward castling and uses the central space. Black must avoid tactics along the e-file and diagonal to the king.'),
('Queen to d6','e4 d5 exd5 Qxd5 Nc3 Qd6 d4 Nf6 Nf3 c6 Bc4 Bf5 O-O e6 Re1', 'Black places the queen closer to the center but it can obstruct development. White completes development and watches for useful tempo gains without overextending.'),
('Queen returns to d8','e4 d5 exd5 Qxd5 Nc3 Qd8 d4 Nf6 Nf3 c6 Bc4 Bf5 O-O e6', 'Black gives back the queen tempo and relies on a sound structure. White has easy development and should convert it into active piece placement rather than an unsupported attack.'),
('Modern ...Nf6','e4 d5 exd5 Nf6 d4 Nxd5 Nf3 g6 c4 Nb6 Nc3 Bg7 Be3 O-O', 'Black recovers the pawn with a knight and adopts a fianchetto. White gains space by attacking the knight. Black must use the bishop and central breaks to avoid passivity.')])

add('Pirc Defense','Other defenses to e4','Intermediate',
'Black allows White a broad center, develops ...Nf6 and fianchettoes the king bishop. The central space is an invitation to counterattack, not a concession to ignore. White chooses how much of that invitation to accept.',
'Build a center that can be supported by pieces. Decide between a restrained setup and an Austrian f4 center; coordinate the king\'s safety before launching a pawn storm.',
'Attack the center with ...c5 or ...e5. Use the g7 bishop and avoid opening the position while too far behind in development.',
'White often has e4/d4 and sometimes f4. Black\'s d6 pawn supports a compact setup but leaves the choice of central break unresolved.',
'White\'s space advantage does not justify pushing every central pawn. Black should not treat ...g6, ...Bg7 and ...O-O as an automatic setup against every attack.',
'The Modern Defense delays ...Nf6. That changes the e4 attack and permits different move orders, even when the final structure looks similar.',[
('Austrian Attack','e4 d6 d4 Nf6 Nc3 g6 f4 Bg7 Nf3 O-O Bd3 Na6 O-O c5 d5', 'White builds a large center and Black attacks its base. The advance d5 gains space but changes the c5 pawn tension. Piece activity must support the advanced center.'),
('Classical system','e4 d6 d4 Nf6 Nc3 g6 Nf3 Bg7 Be2 O-O O-O c6 Re1', 'White develops without overcommitting the f-pawn. Black can prepare ...b5 or central counterplay. The position rewards recognizing the right break rather than forcing an attack.'),
('150 Attack setup','e4 d6 d4 Nf6 Nc3 g6 Be3 Bg7 Qd2 c6 f3 b5 Nge2 Nbd7', 'White reinforces e4 and prepares aggressive options. Black expands on the queenside before committing the king. Both sides should reassess castling choices as the pawn structure changes.'),
('Fianchetto system','e4 d6 d4 Nf6 Nc3 g6 g3 Bg7 Bg2 O-O Nge2 e5 O-O Nc6', 'White develops the bishop behind the center and keeps the f-pawn flexible. Black challenges e4/d4 with ...e5. The central exchanges will determine the useful diagonals.')])

add('Modern Defense','Other defenses to e4','Intermediate',
'Black begins with a kingside fianchetto and delays the g8 knight. White can build a large center, but Black retains flexible pawn breaks and knight routes. The extra flexibility must eventually produce active play.',
'Occupy central space while developing enough pieces to support it. Be prepared for both ...c5 and ...e5, and avoid assuming a single standard black setup.',
'Use the g7 bishop to pressure the center and choose the moment to play ...Nf6. Queenside expansion is useful only if White cannot punish the delay in development.',
'The e4/d4 center can be joined by c4 or f4. Each extra pawn gives space but also creates targets for Black\'s counterattacks.',
'Delaying development is not a strategy by itself. Black must know which central break justifies the move order, and White must calculate rather than merely count center pawns.',
'Many lines transpose to the Pirc or King\'s Indian. Check the presence of c4 and ...Nf6 to identify the relevant structure.',[
('Classical center','e4 g6 d4 Bg7 Nc3 d6 Nf3 a6 Be3 b5 a4 b4 Nd5 Bb7', 'Black gains queenside space while White occupies a central outpost. The bishop on b7 adds pressure against e4. Both sides must balance space with the safety of undeveloped pieces.'),
('Austrian setup','e4 g6 d4 Bg7 Nc3 d6 f4 a6 Nf3 b5 Bd3 Nd7 O-O Bb7', 'White develops behind a broad center; Black uses both bishops to pressure it. The central ...c5 and ...e5 breaks require preparation and cannot be replaced by endless flank moves.'),
('Averbakh system','e4 g6 d4 Bg7 c4 d6 Nc3 Nf6 Nf3 O-O Be2 e5 O-O', 'White includes c4 and the position reaches a King\'s Indian structure. The plans now revolve around d4/d5 and the center, not an independent Modern setup.'),
('Early ...c5','e4 g6 d4 Bg7 Nc3 c5 d5 d6 Nf3 Nf6 Be2 O-O O-O e6', 'White gains space with d5 and Black attacks the chain. The game can resemble a Benoni structure without a white c4 pawn, which changes central control and recapture options.')])

add('Alekhine Defense','Other defenses to e4','Intermediate',
'Black attacks e4 with a knight and invites White to gain space by chasing it. The opening tests whether the advanced pawns become a lasting strength or targets. Black must justify the lost knight tempi with pressure on the center.',
'Gain useful central space and then develop. Choose between the broad Four Pawns setup, a quieter Nf3 system, or early exchanges that reduce the tension.',
'Attack the center with ...d6 and appropriate pawn breaks. Place the knight where it helps challenge the pawns, and finish development before opening lines.',
'White may have pawns on c4, d4 and e5, sometimes joined by f4. Exchanges on d6 lead to different structures depending on Black\'s recapture.',
'Chasing the knight is not always the best use of another tempo. White can overextend; Black can become cramped if counterplay arrives too late.',
'Compare with the Pirc and Modern: all invite a broad center, but the Alekhine spends early knight moves to provoke specific pawn advances.',[
('Modern variation','e4 Nf6 e5 Nd5 d4 d6 Nf3 Bg4 Be2 e6 O-O Be7 c4 Nb6', 'White develops before chasing the knight again. Black pins the f3 knight and pressures the center. The move c4 gains space but commits another pawn that may become a target.'),
('Exchange, ...cxd6','e4 Nf6 e5 Nd5 d4 d6 c4 Nb6 exd6 cxd6 Nc3 g6 Be3 Bg7 Rc1 O-O', 'Black recaptures toward the center and opens the c-file. White develops behind a space advantage. The d6 pawn is a target but also supports useful central squares.'),
('Four Pawns Attack','e4 Nf6 e5 Nd5 d4 d6 c4 Nb6 f4 dxe5 fxe5 Nc6 Be3 Bf5 Nc3 e6', 'White has maximum space and a large center to defend. Black attacks it with pieces and pawn breaks. Development is especially urgent because opening the center can expose the white king.'),
('Exchange, ...exd6','e4 Nf6 e5 Nd5 d4 d6 c4 Nb6 exd6 exd6 Nc3 Be7 Nf3 O-O Be2 Nc6', 'Black chooses a more symmetrical pawn structure and natural development. White retains space, while Black looks for active piece squares and a suitable central break.')])
