import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'lib'))
import chess
from all_courses import COURSES
errors=[]
for c in COURSES:
    for line in c['branches']:
        b=chess.Board()
        for ply,san in enumerate(line['moves'].split()):
            try:
                m=b.parse_san(san)
                assert b.san(m)==san, f'noncanonical: {b.san(m)}'
                b.push(m)
                assert b.is_valid()
            except Exception as e:
                errors.append((c['name'],line['label'],ply+1,san,str(e)));break
for x in errors: print(x)
print(f'{len(COURSES)} courses; {sum(len(c["branches"]) for c in COURSES)} lines; {len(errors)} errors')
sys.exit(bool(errors))
