from course_data import add

add('King s Indian Defense','Indian defenses','Advanced',
'Black allows d4 and e4, fianchettoes the king bishop and attacks the center with ...e5 or ...c5. In closed lines, both sides may attack on different wings. The opening rewards understanding pawn breaks and the timing of piece maneuvers.',
'Use the space advantage to develop and decide whether to close d5. In closed centers, seek queenside play while watching Black\'s ...f5 attack. In open centers, activity and king safety take precedence.',
'Challenge the center and prepare a coherent break. After d5 closes the center, ...f5 can begin kingside play, but it needs piece support and a secure response to central or queenside action.',
'The locked d5/e4 against d6/e5 structure directs play toward the wings. The fianchetto and Four Pawns systems can instead maintain more central tension.',
'Do not start a pawn race automatically. If the center can still open, a flank attack may expose your own king. A thematic sacrifice still requires calculation.',
'The Modern can transpose here after c4 and ...Nf6. The Benoni uses a different central exchange and gives Black a queenside pawn majority.',[
('Classical, closed center','d4 Nf6 c4 g6 Nc3 Bg7 e4 d6 Nf3 O-O Be2 e5 O-O Nc6 d5 Ne7 Ne1 Nd7', 'The center locks and both sides begin rerouting knights. White can prepare queenside expansion; Black plans ...f5. The attacks develop at different speeds, so every tempo has a purpose.'),
('Samisch system','d4 Nf6 c4 g6 Nc3 Bg7 e4 d6 f3 O-O Be3 c5 Nge2 Nc6 d5 Ne5 Ng3', 'White supports e4 with f3 but delays the kingside knight. Black challenges d4 immediately. The resulting center resembles a Benoni in some lines, but the f3 pawn changes king safety.'),
('Fianchetto variation','d4 Nf6 c4 g6 Nf3 Bg7 g3 O-O Bg2 d6 O-O Nbd7 Nc3 e5 e4 c6', 'White develops a solid king shelter and central control. Black prepares counterplay without assuming a direct kingside pawn storm will work against the fianchetto.'),
('Four Pawns Attack','d4 Nf6 c4 g6 Nc3 Bg7 e4 d6 f4 O-O Nf3 c5 d5 e6 Be2 exd5 cxd5', 'White gains maximum space, while Black opens lines against the center. The advanced pawns require active support. Black\'s bishop becomes more effective as central files open.'),
('Averbakh system','d4 Nf6 c4 g6 Nc3 Bg7 e4 d6 Be2 O-O Bg5 c5 d5 e6 Qd2 exd5 exd5', 'White develops the bishop actively before Nf3 and can influence Black\'s freeing moves. Black attacks the center. The recapture determines the resulting pawn majority and useful files.')])

add('Nimzo-Indian Defense','Indian defenses','Intermediate',
'Black pins the c3 knight with ...Bb4 and often gives up the bishop pair to influence the center and pawn structure. White\'s fourth move determines how to respond to that pressure. The opening is a study of dynamic versus structural advantages.',
'Choose how to protect e4 and meet Bxc3. Use the bishop pair in open positions, or recapture with the queen to preserve the pawns if the loss of time is acceptable.',
'Control e4 and use ...c5 or ...d5 to challenge the center. Exchange on c3 only when the resulting structure or tempi fit the plan.',
'After bxc3, White has a strong center and doubled c-pawns that may be targets. After Qxc3, the structure is intact but the queen may lose time.',
'The bishop pair is a potential advantage, not an immediate win. Black should not exchange on c3 merely because it is allowed; White should not ignore development while keeping perfect pawns.',
'The Queen\'s Indian and Bogo-Indian arise when White plays Nf3 instead of Nc3. The choice of knight development changes Black\'s available pins.',[
('Rubinstein system','d4 Nf6 c4 e6 Nc3 Bb4 e3 O-O Bd3 d5 Nf3 c5 O-O Nc6 a3 Bxc3 bxc3', 'White develops solidly and accepts doubled pawns to gain the bishop pair. Black pressures the center. White should look for active central play rather than simply defend every pawn.'),
('Classical Qc2','d4 Nf6 c4 e6 Nc3 Bb4 Qc2 O-O a3 Bxc3+ Qxc3 b6 Bg5 Bb7 e3', 'White preserves the pawn structure but spends queen tempi. Black develops quickly and pressures the center. The queen must avoid becoming an easy target.'),
('Samisch variation','d4 Nf6 c4 e6 Nc3 Bb4 a3 Bxc3+ bxc3 c5 e3 O-O Bd3 Nc6 Ne2', 'White asks the bishop to decide immediately and accepts structural damage. The pawn center can become powerful, but Black has clear targets and rapid development.'),
('Leningrad variation','d4 Nf6 c4 e6 Nc3 Bb4 Bg5 h6 Bh4 c5 d5 d6 e3 Bxc3+ bxc3 e5', 'The center becomes locked and White\'s doubled pawns have a different role than in open Rubinstein lines. Black gains dark-square control while White retains the bishop pair.')])

add('Queen s Indian Defense','Indian defenses','Intermediate',
'Black develops the queen bishop to b7 or a6 after White chooses Nf3. The defense contests e4 without committing the d-pawn immediately. White often fianchettoes the king bishop or uses a3 to prepare Nc3 without a pin.',
'Develop toward central control and decide when to play d5 or e4. Against ...Ba6, protect c4 in a way that also improves coordination.',
'Use the light-square bishop to pressure e4 or c4, develop naturally and seek a well-timed ...d5 or ...c5. Avoid drifting into passive defense of the queenside.',
'The center can remain flexible or become a hanging-pawn structure after exchanges. The two fianchetto bishops may oppose each other on the long diagonal.',
'Do not assume ...Bb7 is always the best bishop square; ...Ba6 can make White spend time defending c4. White should avoid queen moves that create easy tempo targets.',
'The Nimzo-Indian becomes available after Nc3; the Queen\'s Indian is a way to play when White delays that knight. Transpositions require matching the center too.',[
('Classical fianchetto','d4 Nf6 c4 e6 Nf3 b6 g3 Bb7 Bg2 Be7 O-O O-O Nc3 Ne4 Qc2 Nxc3 Qxc3', 'Black centralizes and exchanges a knight to reduce White\'s pressure. White keeps a sound structure and active queen. The long diagonal is an important source of tactics.'),
('...Ba6 system','d4 Nf6 c4 e6 Nf3 b6 g3 Ba6 b3 Bb4+ Bd2 Be7 Bg2 c6 O-O d5', 'Black uses the bishop to provoke b3, then develops with a check. White has a stable setup but has committed queenside pawns. The later central break changes both bishops\' scope.'),
('Petrosian system','d4 Nf6 c4 e6 Nf3 b6 a3 Bb7 Nc3 d5 cxd5 Nxd5 e3 Be7 Bd3 O-O', 'White prevents a pin on b4 before developing Nc3. Black responds centrally. The extra a3 move is useful only if White takes advantage of the resulting freedom.'),
('Quiet e3 setup','d4 Nf6 c4 e6 Nf3 b6 e3 Bb7 Bd3 d5 O-O Bd6 Nc3 O-O', 'Both sides develop harmoniously. White can prepare e4 while Black contests the center. The restrained setup is a good exercise in finding a useful plan after development is complete.')])

add('Grunfeld Defense','Indian defenses','Advanced',
'Black combines a fianchetto with an early ...d5, often allowing White a broad pawn center after exchanges. The opening relies on active pressure against that center. Material and structural imbalances arise quickly, so concrete calculation is essential.',
'Build and support the center without overextending. Use space to develop actively, and decide whether a central advance improves the position or creates targets.',
'Pressure d4 with ...c5, the g7 bishop and active pieces. Seek exchanges that weaken the center rather than simply reduce material.',
'The Exchange variation gives White pawns on c3, d4 and e4 against Black\'s active pieces. Russian and fianchetto systems keep different central tensions.',
'Do not describe White\'s center as either automatically strong or automatically weak. Its value depends on development, tactical defense and the timing of central advances.',
'Compare with the King\'s Indian: the Grunfeld challenges d4 immediately with ...d5, leading to more open central play.',[
('Exchange, classical development','d4 Nf6 c4 g6 Nc3 d5 cxd5 Nxd5 e4 Nxc3 bxc3 Bg7 Nf3 c5 Be3 Qa5 Qd2 O-O Rc1', 'White supports the center and develops the rook to an active file. Black attacks d4 and the queenside. The queen on a5 creates concrete pressure rather than a general flank attack.'),
('Exchange with Bc4','d4 Nf6 c4 g6 Nc3 d5 cxd5 Nxd5 e4 Nxc3 bxc3 Bg7 Bc4 c5 Ne2 Nc6 Be3 O-O O-O', 'White places the bishop actively and uses Ne2 to support the center without blocking the f-pawn. Black challenges d4 with multiple pieces. Tactics decide which pawn advances are safe.'),
('Russian system','d4 Nf6 c4 g6 Nc3 d5 Nf3 Bg7 Qb3 dxc4 Qxc4 O-O e4 Na6 Be2 c5 d5', 'White uses the queen to recover c4 and establish central space. Black gains development tempi and attacks the center. The queen must be placed carefully as the position opens.'),
('Fianchetto variation','d4 Nf6 c4 g6 Nf3 Bg7 g3 d5 cxd5 Nxd5 Bg2 Nb6 O-O O-O Nc3 Nc6', 'White chooses a stable king shelter and central restraint. Black develops actively without allowing the broad Exchange center. The game becomes a more positional struggle over central squares.')])

add('Bogo-Indian Defense','Indian defenses','Foundation',
'Black gives ...Bb4+ after White develops Nf3. The check asks White to choose a blocking piece and can help Black simplify development. The resulting structure matters more than the fact that a check was given.',
'Choose Bd2 for a direct bishop challenge or Nbd2 to retain pieces. Develop smoothly and use central space; avoid awkward coordination just to keep the bishop pair.',
'Use the check to improve development or obtain favorable exchanges. Follow with a coherent ...d6/...e5 or ...d5 plan and resolve the c8 bishop.',
'The center may stay flexible or become a closed d5/e4 structure. Bishop exchanges can reduce attacking chances while making pawn breaks more important.',
'A check is not automatically useful. If the bishop retreats repeatedly without gaining anything, Black may simply lose time. White should understand which piece is being obstructed by an interposition.',
'The Bogo-Indian complements the Nimzo-Indian against a White Nf3 move order. Catalan setups can arise when White follows with g3.',[
('Bishop exchange','d4 Nf6 c4 e6 Nf3 Bb4+ Bd2 Bxd2+ Qxd2 O-O Nc3 d5 e3 b6 Bd3', 'Black simplifies and develops the remaining bishop toward the center. White has easy development and a sound structure. The queen on d2 can support central play but should avoid unnecessary exposure.'),
('Queen support','d4 Nf6 c4 e6 Nf3 Bb4+ Bd2 Qe7 g3 Nc6 Bg2 Bxd2+ Nbxd2 d6 O-O e5', 'Black keeps the bishop decision flexible before establishing a central strongpoint. White develops the knight to d2 through the recapture, which changes the usual Nc3 plans.'),
('Nbd2 system','d4 Nf6 c4 e6 Nf3 Bb4+ Nbd2 b6 a3 Bxd2+ Bxd2 Bb7 e3 O-O Bd3 d5', 'White keeps the queen home and develops the bishop through recapture. Black fianchettoes the c8 bishop. The a3 move gains a decision from Black but also spends a tempo.'),
('Bishop retreat','d4 Nf6 c4 e6 Nf3 Bb4+ Bd2 Be7 g3 d5 Bg2 O-O O-O c6 Qc2', 'Black returns the bishop and reaches a Catalan-like closed center. White\'s bishop on d2 differs from other Catalan move orders, so the position should be assessed on its own merits.')])

add('Catalan Opening','Indian defenses','Intermediate',
'White combines d4 and c4 with a kingside fianchetto. The bishop on g2 creates lasting pressure on the queenside and center. Black can accept the c4 pawn or retain the center, producing Open and Closed Catalan structures.',
'Activate the g2 bishop, recover c4 without losing the initiative and pressure the long diagonal. Be willing to sacrifice a pawn temporarily when the resulting activity is real and calculable.',
'Choose whether to take c4 and how to return or defend it. Develop the queenside and seek ...c5 or ...e5 rather than remain tied to a pawn.',
'The long diagonal can become decisive when the d5 pawn moves or exchanges. Open Catalan positions often involve pressure on b7 and c6; Closed systems retain central tension.',
'Do not assume every pawn sacrifice is justified by the bishop on g2. Verify how the other pieces enter the game and whether Black can neutralize the diagonal.',
'Compare with the Queen\'s Indian and QGD. The g2 bishop changes the tactical meaning of ...dxc4 and queenside development.',[
('Open Catalan, early recovery','d4 Nf6 c4 e6 g3 d5 Bg2 Be7 Nf3 O-O O-O dxc4 Qc2 a6 Qxc4 b5 Qc2 Bb7', 'Black returns the pawn while gaining queenside space and developing the bishop. White keeps pressure on the long diagonal. The queen has moved several times, so development still matters.'),
('Closed Catalan','d4 Nf6 c4 e6 g3 d5 Bg2 Be7 Nf3 O-O O-O Nbd7 Qc2 c6 Nbd2 b6 e4', 'White prepares e4 behind a stable center. Black develops compactly and must decide when to challenge the pawn duo. The central break is a strategic objective, not an automatic move.'),
('Open Catalan with ...Nc6','d4 Nf6 c4 e6 g3 d5 Bg2 Be7 Nf3 O-O O-O dxc4 Qc2 Nc6 Qxc4 Qd5 Qxd5 exd5', 'The queens are exchanged and the structure changes. White\'s bishop retains long-term pressure, but the game now rewards endgame activity rather than a direct attack.'),
('Early check move order','d4 Nf6 c4 e6 g3 Bb4+ Bd2 Be7 Bg2 d5 Nf3 O-O O-O c6 Qc2', 'The bishop check changes White\'s development before the Catalan center forms. The bishop on d2 may affect the knight\'s development and central coordination.')])

add('Modern Benoni','Indian defenses','Advanced',
'Black exchanges the e-pawn for White\'s c-pawn and accepts a central space disadvantage. In return, Black gets an active g7 bishop, the semi-open e-file and a queenside pawn majority. The position is strategically rich and tactically demanding.',
'Use the d5 wedge to gain space, restrain ...b5 and prepare e4-e5 when supported. Improve pieces before pushing further; the center must remain defensible.',
'Use ...b5 or ...f5 to create counterplay, pressure e4 and activate the g7 bishop. Avoid passive defense of d6 without a plan to free the pieces.',
'White has a central pawn majority and an advanced d5 pawn. Black has a queenside majority and a backward d6 pawn. Each side attacks where its structure provides leverage.',
'The ...b5 break can be vital but often needs preparation. White\'s e5 advance can be strong but may fail tactically if the d5 pawn or king is exposed.',
'Some King\'s Indian and Modern move orders transpose here. Check which white pawn recaptured on d5, because that determines the pawn majorities.',[
('Modern main setup','d4 Nf6 c4 c5 d5 e6 Nc3 exd5 cxd5 d6 e4 g6 Nf3 Bg7 h3 O-O Bd3 b5', 'White prevents an easy ...Bg4 pin and develops toward castling. Black counters on the queenside. The pawn break requires concrete analysis and should not be copied into unrelated positions.'),
('Fianchetto variation','d4 Nf6 c4 c5 d5 e6 Nc3 exd5 cxd5 d6 Nf3 g6 g3 Bg7 Bg2 O-O O-O Re8', 'White builds a secure king shelter and restrains the center. Black uses the e-file and active bishop. The game is more positional than the sharpest f4 systems.'),
('Taimanov Attack','d4 Nf6 c4 c5 d5 e6 Nc3 exd5 cxd5 d6 e4 g6 f4 Bg7 Bb5+ Nfd7 a4 O-O Nf3', 'White combines maximum central space with a forcing check. Black\'s knight interposition affects development. This is a concrete attacking system that requires more preparation than quieter Benoni lines.'),
('Classical development','d4 Nf6 c4 c5 d5 e6 Nc3 exd5 cxd5 d6 e4 g6 Nf3 Bg7 Be2 O-O O-O Re8 Nd2', 'White reroutes the knight to support central play and restrain counterplay. Black pressures e4 and seeks a freeing break. The backward d6 pawn matters most if White can attack it without losing activity.')])

add('Benko Gambit','Indian defenses','Intermediate',
'Black offers a queenside pawn with ...b5 and ...a6 to open the a- and b-files. The compensation is usually long-term pressure, not a quick mating attack. White can accept fully, return material, or decline the gambit.',
'Develop efficiently and protect the queenside without becoming passive. Consider returning the extra pawn if it neutralizes the files and frees the pieces.',
'Use the open files and g7 bishop to pressure the queenside. Coordinate rooks and minor pieces; avoid spending time trying to force a quick win of the pawn back.',
'Black may have open a- and b-files against White\'s a- and b-pawns. White has an extra pawn but may struggle to free the queenside pieces.',
'The extra pawn is not a reason to exchange indiscriminately: some endgames favor Black\'s persistent activity. Conversely, compensation is not a guarantee if White neutralizes the files.',
'The Benoni shares the g7 bishop and d6/c5 structure, but the Benko opens queenside files through a pawn sacrifice.',[
('Accepted, classical king route','d4 Nf6 c4 c5 d5 b5 cxb5 a6 bxa6 Bxa6 Nc3 d6 e4 Bxf1 Kxf1 g6 g3 Bg7 Kg2', 'White gives up castling but walks the king to safety. Black gains persistent queenside pressure. The king route is part of this exact structure and should not be generalized to unrelated gambits.'),
('Accepted, fianchetto','d4 Nf6 c4 c5 d5 b5 cxb5 a6 bxa6 Bxa6 Nc3 d6 Nf3 g6 g3 Bg7 Bg2 O-O O-O', 'White preserves normal castling and builds a solid king position. Black will pressure the queenside files. White needs a development plan for the queenside pieces before defending passively.'),
('Declined with b6','d4 Nf6 c4 c5 d5 b5 cxb5 a6 b6 Qxb6 Nc3 d6 e4 g6 Nf3 Bg7', 'White returns material to alter the queenside structure. Black\'s queen becomes active but may be exposed to tempo attacks. The game is no longer the standard fully accepted Benko.'),
('Declined with Nf3','d4 Nf6 c4 c5 d5 b5 Nf3 g6 cxb5 a6 bxa6 Bxa6 Nc3 d6 g3 Bg7', 'White develops before deciding the pawn captures and can transpose to a fianchetto structure. Follow the exact move order to see whether Black has gained or lost a useful tempo.')])

add('Dutch Defense','Indian defenses','Intermediate',
'Black plays ...f5 to control e4 and create an asymmetrical game. The Stonewall, Classical and Leningrad systems have different bishop placements and central plans. The weakened diagonal to the black king is an enduring tactical factor.',
'Develop actively, control e5 and challenge the center. A kingside fianchetto is a reliable structural choice, but sharper early systems need independent preparation.',
'Choose a coherent pawn structure and develop the bishops accordingly. Use e4 as an outpost when supported, and keep the king safe before opening the kingside.',
'The Stonewall uses pawns on f5/e6/d5/c6 and leaves e5 weak. The Leningrad fianchettoes the bishop and often prepares ...e5. The Classical keeps the bishop on e7.',
'The f-pawn advance weakens e8-h5 and can make early checks dangerous. Do not launch a kingside attack before completing development and accounting for central breaks.',
'Bird\'s Opening reverses the first-move idea, but the extra tempo and side to move change the tactical details.',[
('Leningrad system','d4 f5 g3 Nf6 Bg2 g6 Nf3 Bg7 O-O O-O c4 d6 Nc3 Qe8 d5', 'Black prepares central expansion with ...e5 while White gains space. The queen move supports the break but can also be part of kingside play. The center determines whether that attack is timely.'),
('Stonewall','d4 f5 g3 Nf6 Bg2 e6 Nf3 d5 O-O Bd6 c4 c6 b3 O-O Ba3', 'White aims to exchange Black\'s active dark-square bishop. Black must solve the restricted c8 bishop and watch e5. The fixed center makes good and bad minor pieces especially important.'),
('Classical Dutch','d4 f5 g3 Nf6 Bg2 e6 Nf3 Be7 O-O O-O c4 d6 Nc3 Qe8', 'Black keeps the d-pawn flexible and can prepare ...e5. White develops toward central control. The queen on e8 needs a concrete follow-up rather than a routine kingside excursion.'),
('Staunton Gambit','d4 f5 e4 fxe4 Nc3 Nf6 Bg5 g6 f3 exf3 Nxf3 Bg7 Qd2 O-O', 'White offers a pawn to accelerate development and pressure Black\'s weakened king position. Black accepts and develops. Both sides must assess concrete threats instead of relying on the gambit\'s reputation.')])
