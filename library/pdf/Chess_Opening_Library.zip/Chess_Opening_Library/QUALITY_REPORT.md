# Quality report

Build date: 2026-09-04. This report distinguishes legal correctness, finite engine screening and visual/layout checks.

## Completed checks

- Exactly 50 course folders, each with three PDFs and two nonempty PGNs; one additional 12-page introductory guide.
- 151 PDFs, 1,170 pages and 916 generated board diagrams.
- All 202 authored opening routes, comprising 3,235 plies, replayed with legal moves, canonical SAN and valid board states.
- Every diagram FEN validated. The same board objects generate the printed positions and the move notation; captions derive the side to move from the board.
- All 3,273 exported PGN records parsed, including 41,336 moves across main lines and engine variations. No illegal move, invalid board or empty PGN file remained. Reference records can overlap between related courses.
- All PDF files reopened successfully; page counts, letter-page dimensions and extracted text checked. No empty pages or replacement-character findings.
- All 1,170 pages rendered through Poppler. Zero renderer failures. Layout rectangles were checked for text/text and text/board collisions; zero remained in the final build. Representative rendered course pages and the guide were visually reviewed at page and contact-sheet scale.
- SHA-256 hashes for delivered PDFs are recorded in `manifest.json`.

## Engine screening

Stockfish 18, two threads and 128 MiB hash. Each unique position along the authored routes was initially searched with a 60,000-node budget. Estimated move losses greater than 1.40 pawn units triggered comparison searches of 650,000 nodes for the best move and 450,000 nodes restricted to the authored move. Confirmed losses greater than 1.20 pawn units were flagged for revision. The final authored routes had zero remaining flags by this procedure.

Candidate exercises use a 350,000-node MultiPV-3 search at each route endpoint. Recorded candidate depths range from 11 to 16 (median 13); exact per-position depths, nodes, scores and continuations are preserved in `source/engine_cache.json`. When Stockfish returned a short principal variation, additional 350,000-node searches from its endpoint extended the sample to eight plies (unless the game ended earlier). These extension searches are also recorded. All printed continuations are checked for legality.

The initial review caught and corrected tactical weaknesses in a Ponziani teaching line and a King's Gambit continuation. Canonical-SAN checks also corrected unnecessary knight disambiguation. Layout review caught and corrected an answer-page subtitle/heading collision.

## Practical limits

Legal moves are not necessarily best moves. This finite screening is designed to catch substantial tactical errors; it is not exhaustive analysis or proof of theoretical correctness. A lower threshold, more nodes or another engine version can produce different assessments. Even a sound gambit can receive a less favorable objective score than a quiet alternative.

Reference PGNs are a named-position catalog from Lichess: legal move sequences, but not all engine-reviewed recommendations. Some include gambits, traps, rare sidelines or historical lines. They are kept separate from the authored teaching routes and labeled accordingly.

The prose is original instructional synthesis, supported by the displayed legal positions. It has not undergone independent titled-player editorial review. Engine continuations are generated study examples, not invented historical games. Evaluations use White's perspective and are not win probabilities. The collection is a broad educational survey rather than a complete competitive repertoire.
