# Chess Opening Library

Start with [00_Start_Here.pdf](00_Start_Here.pdf).

**50 course folders · 150 course PDFs + one guide · 1,170 pages · 916 vector diagrams · 202 authored opening routes and practice positions.**

This is an original learning survey of important openings, families and systems. “Top 50” is interpreted as a broad educational selection, not a statistical popularity ranking. Large families are split into manageable courses; some structures and reference lines overlap deliberately.

Each folder has three PDFs: foundations and plans, annotated variations, and practice with answers. Course PDFs contain 4-12 pages each. The PGNs let you replay the moves in a chess application. `Annotated_Lines.pgn` contains the authored routes and illustrative engine continuations. `Reference_Variations.pgn` contains additional named positions from the Lichess CC0 dataset; those reference entries are not all engine-screened recommendations.

The board style follows the provided example: cream and green squares, coordinates, dark silhouettes and outlined white pieces. All boards are viewed from White's side, with the side to move printed below.

## Course index

| # | Opening | Level | Foundations | Variations | Practice |
|---|---|---|---|---|---|
| 01 | Italian Game | Foundation | [PDF](01_italian_game/01_Foundations_and_Plans.pdf) | [PDF](01_italian_game/02_Annotated_Variations.pdf) | [PDF](01_italian_game/03_Practice_and_Answers.pdf) |
| 02 | Ruy Lopez | Intermediate | [PDF](02_ruy_lopez/01_Foundations_and_Plans.pdf) | [PDF](02_ruy_lopez/02_Annotated_Variations.pdf) | [PDF](02_ruy_lopez/03_Practice_and_Answers.pdf) |
| 03 | Scotch Game | Foundation | [PDF](03_scotch_game/01_Foundations_and_Plans.pdf) | [PDF](03_scotch_game/02_Annotated_Variations.pdf) | [PDF](03_scotch_game/03_Practice_and_Answers.pdf) |
| 04 | Four Knights Game | Foundation | [PDF](04_four_knights_game/01_Foundations_and_Plans.pdf) | [PDF](04_four_knights_game/02_Annotated_Variations.pdf) | [PDF](04_four_knights_game/03_Practice_and_Answers.pdf) |
| 05 | Petroff Defense | Foundation | [PDF](05_petroff_defense/01_Foundations_and_Plans.pdf) | [PDF](05_petroff_defense/02_Annotated_Variations.pdf) | [PDF](05_petroff_defense/03_Practice_and_Answers.pdf) |
| 06 | Philidor Defense | Foundation | [PDF](06_philidor_defense/01_Foundations_and_Plans.pdf) | [PDF](06_philidor_defense/02_Annotated_Variations.pdf) | [PDF](06_philidor_defense/03_Practice_and_Answers.pdf) |
| 07 | Vienna Game | Foundation | [PDF](07_vienna_game/01_Foundations_and_Plans.pdf) | [PDF](07_vienna_game/02_Annotated_Variations.pdf) | [PDF](07_vienna_game/03_Practice_and_Answers.pdf) |
| 08 | King's Gambit | Advanced | [PDF](08_king_s_gambit/01_Foundations_and_Plans.pdf) | [PDF](08_king_s_gambit/02_Annotated_Variations.pdf) | [PDF](08_king_s_gambit/03_Practice_and_Answers.pdf) |
| 09 | Evans Gambit | Intermediate | [PDF](09_evans_gambit/01_Foundations_and_Plans.pdf) | [PDF](09_evans_gambit/02_Annotated_Variations.pdf) | [PDF](09_evans_gambit/03_Practice_and_Answers.pdf) |
| 10 | Ponziani Opening | Foundation | [PDF](10_ponziani_opening/01_Foundations_and_Plans.pdf) | [PDF](10_ponziani_opening/02_Annotated_Variations.pdf) | [PDF](10_ponziani_opening/03_Practice_and_Answers.pdf) |
| 11 | Bishop's Opening | Foundation | [PDF](11_bishop_s_opening/01_Foundations_and_Plans.pdf) | [PDF](11_bishop_s_opening/02_Annotated_Variations.pdf) | [PDF](11_bishop_s_opening/03_Practice_and_Answers.pdf) |
| 12 | Danish Gambit and Center Game | Intermediate | [PDF](12_danish_gambit_and_center_game/01_Foundations_and_Plans.pdf) | [PDF](12_danish_gambit_and_center_game/02_Annotated_Variations.pdf) | [PDF](12_danish_gambit_and_center_game/03_Practice_and_Answers.pdf) |
| 13 | Sicilian Najdorf | Advanced | [PDF](13_sicilian_najdorf/01_Foundations_and_Plans.pdf) | [PDF](13_sicilian_najdorf/02_Annotated_Variations.pdf) | [PDF](13_sicilian_najdorf/03_Practice_and_Answers.pdf) |
| 14 | Sicilian Dragon | Advanced | [PDF](14_sicilian_dragon/01_Foundations_and_Plans.pdf) | [PDF](14_sicilian_dragon/02_Annotated_Variations.pdf) | [PDF](14_sicilian_dragon/03_Practice_and_Answers.pdf) |
| 15 | Classical Sicilian | Advanced | [PDF](15_classical_sicilian/01_Foundations_and_Plans.pdf) | [PDF](15_classical_sicilian/02_Annotated_Variations.pdf) | [PDF](15_classical_sicilian/03_Practice_and_Answers.pdf) |
| 16 | Sicilian Sveshnikov | Advanced | [PDF](16_sicilian_sveshnikov/01_Foundations_and_Plans.pdf) | [PDF](16_sicilian_sveshnikov/02_Annotated_Variations.pdf) | [PDF](16_sicilian_sveshnikov/03_Practice_and_Answers.pdf) |
| 17 | Sicilian Taimanov | Intermediate | [PDF](17_sicilian_taimanov/01_Foundations_and_Plans.pdf) | [PDF](17_sicilian_taimanov/02_Annotated_Variations.pdf) | [PDF](17_sicilian_taimanov/03_Practice_and_Answers.pdf) |
| 18 | Sicilian Kan | Intermediate | [PDF](18_sicilian_kan/01_Foundations_and_Plans.pdf) | [PDF](18_sicilian_kan/02_Annotated_Variations.pdf) | [PDF](18_sicilian_kan/03_Practice_and_Answers.pdf) |
| 19 | Accelerated Dragon | Intermediate | [PDF](19_accelerated_dragon/01_Foundations_and_Plans.pdf) | [PDF](19_accelerated_dragon/02_Annotated_Variations.pdf) | [PDF](19_accelerated_dragon/03_Practice_and_Answers.pdf) |
| 20 | Sicilian Scheveningen | Advanced | [PDF](20_sicilian_scheveningen/01_Foundations_and_Plans.pdf) | [PDF](20_sicilian_scheveningen/02_Annotated_Variations.pdf) | [PDF](20_sicilian_scheveningen/03_Practice_and_Answers.pdf) |
| 21 | Alapin Sicilian | Foundation | [PDF](21_alapin_sicilian/01_Foundations_and_Plans.pdf) | [PDF](21_alapin_sicilian/02_Annotated_Variations.pdf) | [PDF](21_alapin_sicilian/03_Practice_and_Answers.pdf) |
| 22 | Closed Sicilian | Foundation | [PDF](22_closed_sicilian/01_Foundations_and_Plans.pdf) | [PDF](22_closed_sicilian/02_Annotated_Variations.pdf) | [PDF](22_closed_sicilian/03_Practice_and_Answers.pdf) |
| 23 | Grand Prix Attack | Intermediate | [PDF](23_grand_prix_attack/01_Foundations_and_Plans.pdf) | [PDF](23_grand_prix_attack/02_Annotated_Variations.pdf) | [PDF](23_grand_prix_attack/03_Practice_and_Answers.pdf) |
| 24 | Rossolimo and Moscow Sicilians | Intermediate | [PDF](24_rossolimo_and_moscow_sicilians/01_Foundations_and_Plans.pdf) | [PDF](24_rossolimo_and_moscow_sicilians/02_Annotated_Variations.pdf) | [PDF](24_rossolimo_and_moscow_sicilians/03_Practice_and_Answers.pdf) |
| 25 | French Defense | Intermediate | [PDF](25_french_defense/01_Foundations_and_Plans.pdf) | [PDF](25_french_defense/02_Annotated_Variations.pdf) | [PDF](25_french_defense/03_Practice_and_Answers.pdf) |
| 26 | Caro-Kann Defense | Foundation | [PDF](26_caro_kann_defense/01_Foundations_and_Plans.pdf) | [PDF](26_caro_kann_defense/02_Annotated_Variations.pdf) | [PDF](26_caro_kann_defense/03_Practice_and_Answers.pdf) |
| 27 | Scandinavian Defense | Foundation | [PDF](27_scandinavian_defense/01_Foundations_and_Plans.pdf) | [PDF](27_scandinavian_defense/02_Annotated_Variations.pdf) | [PDF](27_scandinavian_defense/03_Practice_and_Answers.pdf) |
| 28 | Pirc Defense | Intermediate | [PDF](28_pirc_defense/01_Foundations_and_Plans.pdf) | [PDF](28_pirc_defense/02_Annotated_Variations.pdf) | [PDF](28_pirc_defense/03_Practice_and_Answers.pdf) |
| 29 | Modern Defense | Intermediate | [PDF](29_modern_defense/01_Foundations_and_Plans.pdf) | [PDF](29_modern_defense/02_Annotated_Variations.pdf) | [PDF](29_modern_defense/03_Practice_and_Answers.pdf) |
| 30 | Alekhine Defense | Intermediate | [PDF](30_alekhine_defense/01_Foundations_and_Plans.pdf) | [PDF](30_alekhine_defense/02_Annotated_Variations.pdf) | [PDF](30_alekhine_defense/03_Practice_and_Answers.pdf) |
| 31 | Queen's Gambit Declined | Foundation | [PDF](31_queen_s_gambit_declined/01_Foundations_and_Plans.pdf) | [PDF](31_queen_s_gambit_declined/02_Annotated_Variations.pdf) | [PDF](31_queen_s_gambit_declined/03_Practice_and_Answers.pdf) |
| 32 | Queen's Gambit Accepted | Foundation | [PDF](32_queen_s_gambit_accepted/01_Foundations_and_Plans.pdf) | [PDF](32_queen_s_gambit_accepted/02_Annotated_Variations.pdf) | [PDF](32_queen_s_gambit_accepted/03_Practice_and_Answers.pdf) |
| 33 | Slav Defense | Foundation | [PDF](33_slav_defense/01_Foundations_and_Plans.pdf) | [PDF](33_slav_defense/02_Annotated_Variations.pdf) | [PDF](33_slav_defense/03_Practice_and_Answers.pdf) |
| 34 | Semi-Slav Defense | Advanced | [PDF](34_semi_slav_defense/01_Foundations_and_Plans.pdf) | [PDF](34_semi_slav_defense/02_Annotated_Variations.pdf) | [PDF](34_semi_slav_defense/03_Practice_and_Answers.pdf) |
| 35 | King's Indian Defense | Advanced | [PDF](35_king_s_indian_defense/01_Foundations_and_Plans.pdf) | [PDF](35_king_s_indian_defense/02_Annotated_Variations.pdf) | [PDF](35_king_s_indian_defense/03_Practice_and_Answers.pdf) |
| 36 | Nimzo-Indian Defense | Intermediate | [PDF](36_nimzo_indian_defense/01_Foundations_and_Plans.pdf) | [PDF](36_nimzo_indian_defense/02_Annotated_Variations.pdf) | [PDF](36_nimzo_indian_defense/03_Practice_and_Answers.pdf) |
| 37 | Queen's Indian Defense | Intermediate | [PDF](37_queen_s_indian_defense/01_Foundations_and_Plans.pdf) | [PDF](37_queen_s_indian_defense/02_Annotated_Variations.pdf) | [PDF](37_queen_s_indian_defense/03_Practice_and_Answers.pdf) |
| 38 | Grunfeld Defense | Advanced | [PDF](38_grunfeld_defense/01_Foundations_and_Plans.pdf) | [PDF](38_grunfeld_defense/02_Annotated_Variations.pdf) | [PDF](38_grunfeld_defense/03_Practice_and_Answers.pdf) |
| 39 | Bogo-Indian Defense | Foundation | [PDF](39_bogo_indian_defense/01_Foundations_and_Plans.pdf) | [PDF](39_bogo_indian_defense/02_Annotated_Variations.pdf) | [PDF](39_bogo_indian_defense/03_Practice_and_Answers.pdf) |
| 40 | Catalan Opening | Intermediate | [PDF](40_catalan_opening/01_Foundations_and_Plans.pdf) | [PDF](40_catalan_opening/02_Annotated_Variations.pdf) | [PDF](40_catalan_opening/03_Practice_and_Answers.pdf) |
| 41 | Modern Benoni | Advanced | [PDF](41_modern_benoni/01_Foundations_and_Plans.pdf) | [PDF](41_modern_benoni/02_Annotated_Variations.pdf) | [PDF](41_modern_benoni/03_Practice_and_Answers.pdf) |
| 42 | Benko Gambit | Intermediate | [PDF](42_benko_gambit/01_Foundations_and_Plans.pdf) | [PDF](42_benko_gambit/02_Annotated_Variations.pdf) | [PDF](42_benko_gambit/03_Practice_and_Answers.pdf) |
| 43 | Dutch Defense | Intermediate | [PDF](43_dutch_defense/01_Foundations_and_Plans.pdf) | [PDF](43_dutch_defense/02_Annotated_Variations.pdf) | [PDF](43_dutch_defense/03_Practice_and_Answers.pdf) |
| 44 | London System | Foundation | [PDF](44_london_system/01_Foundations_and_Plans.pdf) | [PDF](44_london_system/02_Annotated_Variations.pdf) | [PDF](44_london_system/03_Practice_and_Answers.pdf) |
| 45 | Colle System | Foundation | [PDF](45_colle_system/01_Foundations_and_Plans.pdf) | [PDF](45_colle_system/02_Annotated_Variations.pdf) | [PDF](45_colle_system/03_Practice_and_Answers.pdf) |
| 46 | Trompowsky Attack | Intermediate | [PDF](46_trompowsky_attack/01_Foundations_and_Plans.pdf) | [PDF](46_trompowsky_attack/02_Annotated_Variations.pdf) | [PDF](46_trompowsky_attack/03_Practice_and_Answers.pdf) |
| 47 | English Opening | Intermediate | [PDF](47_english_opening/01_Foundations_and_Plans.pdf) | [PDF](47_english_opening/02_Annotated_Variations.pdf) | [PDF](47_english_opening/03_Practice_and_Answers.pdf) |
| 48 | Reti Opening | Intermediate | [PDF](48_reti_opening/01_Foundations_and_Plans.pdf) | [PDF](48_reti_opening/02_Annotated_Variations.pdf) | [PDF](48_reti_opening/03_Practice_and_Answers.pdf) |
| 49 | King's Indian Attack | Foundation | [PDF](49_king_s_indian_attack/01_Foundations_and_Plans.pdf) | [PDF](49_king_s_indian_attack/02_Annotated_Variations.pdf) | [PDF](49_king_s_indian_attack/03_Practice_and_Answers.pdf) |
| 50 | Bird's Opening | Intermediate | [PDF](50_bird_s_opening/01_Foundations_and_Plans.pdf) | [PDF](50_bird_s_opening/02_Annotated_Variations.pdf) | [PDF](50_bird_s_opening/03_Practice_and_Answers.pdf) |

## Use and extend

Know the basic rules before starting. Begin with one Foundation course and one branch, then study both sides. The Advanced label marks greater calculation and move-order demands, not a claim that the opening is stronger.

These courses cover selected important branches, plans, structural themes and training continuations. They are not an exhaustive encyclopedia, a complete master-game anthology or a response to every legal move. The reference PGNs provide a wider map for further study.

Read [QUALITY_REPORT.md](QUALITY_REPORT.md) for the checks and their limits, [NOTICE.md](NOTICE.md) for attribution, [LICENSE.txt](LICENSE.txt) for the license, and [source/REBUILD.md](source/REBUILD.md) for editable sources and rebuilding instructions. The library is ready to copy into a GitHub repository; nothing has been published automatically.
