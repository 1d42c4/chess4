# Attribution and license notices

The original course text, course data, PDF compilation and builder are provided under GNU GPL version 3 or later. The full license is in LICENSE.txt. Editable source is included in source/.

## Chess piece artwork

Colin M. L. Burnett (Cburnett), GPL version 2 or later, as distributed in python-chess. The board renderer changes black outlines to dark navy and white fills to warm white; the underlying piece geometry is retained. The original SVG piece sources are included in source/piece_artwork/. Distribution of this collection selects GPL version 3 or later, compatible with the artwork's “version 2 or later” option.

References: https://github.com/niklasf/python-chess/blob/master/chess/svg.py and https://github.com/lichess-org/lila/tree/master/public/piece/cburnett .

## Opening names and reference routes

Lichess chess-openings contributors, CC0 1.0 Universal. Source: https://github.com/lichess-org/chess-openings . The five original TSV files and CC0 text are included in source/assets/. Retrieved 2026-09-04. This data is a naming/position reference and does not imply Lichess endorsement of the original lessons.

## Fonts

Noto Sans, Copyright 2018 The Noto Project Authors, SIL Open Font License 1.1. Font files and the full license are included in source/fonts/. Source: https://github.com/notofonts/noto-fonts .

## Software used

python-chess 1.11.2 (GPL-3.0-or-later) for legal moves, notation, PGN handling and SVG piece definitions; Stockfish 18 (GPL-3.0) for analysis; ReportLab and svglib for vector PDF generation; pypdf for PDF checks; Poppler for rendering; Pillow for QA contact sheets. Dependency distributions and the Stockfish binary are not bundled. The supplied requirements and rebuild guide identify the dependencies.

The user's example.pdf was used as a layout reference, not copied into this distribution. All teaching prose and course organization were created for this collection.
